import { create } from "zustand";
import { Vector3 } from "three";

export interface DetailContent {
  type: "evolution" | "achievement" | "skill" | "project" | "experience" | "education";
  id: string;
  title: string;
  subtitle?: string;
  description?: string;
  items?: { label: string; value: string }[];
  tags?: string[];
  meta?: Record<string, string>;
}

interface AppState {
  activeSection: number;
  previousSection: number;
  isTransitioning: boolean;
  selectedObject: string | null;
  detailPanelOpen: boolean;
  detailContent: DetailContent | null;
  cameraTarget: { position: Vector3; lookAt: Vector3 };
  cameraMode: "free" | "focused" | "cinematic";
  loading: boolean;
  backButtonVisible: boolean;
  currentSubsection: string | null;
  masterBallOpen: boolean;

  setActiveSection: (section: number) => void;
  setTransitioning: (v: boolean) => void;
  selectObject: (id: string | null, content?: DetailContent | null) => void;
  setDetailPanelOpen: (v: boolean) => void;
  setCameraTarget: (pos: Vector3, lookAt: Vector3) => void;
  setCameraMode: (mode: "free" | "focused" | "cinematic") => void;
  setLoading: (v: boolean) => void;
  setBackButtonVisible: (v: boolean) => void;
  setCurrentSubsection: (sub: string | null) => void;
  setMasterBallOpen: (v: boolean) => void;
  goBack: () => void;
}

const sectionCameraPositions: { position: Vector3; lookAt: Vector3 }[] = [
  { position: new Vector3(0, 0, 8), lookAt: new Vector3(0, 0, 0) },
  { position: new Vector3(0, 2, 14), lookAt: new Vector3(0, 0, 0) },
  { position: new Vector3(0, 5, 16), lookAt: new Vector3(0, 0, 0) },
  { position: new Vector3(0, 3, 14), lookAt: new Vector3(0, 0, 0) },
  { position: new Vector3(0, 5, 18), lookAt: new Vector3(0, 0, 0) },
  { position: new Vector3(0, 2, 14), lookAt: new Vector3(0, 0, 0) },
  { position: new Vector3(0, 5, 18), lookAt: new Vector3(0, 0, -2) },
  { position: new Vector3(0, 2, 10), lookAt: new Vector3(0, 0, 0) },
];

export const sectionNames = [
  "License",
  "Evolution",
  "Experience",
  "Achievements",
  "Skills",
  "Projects",
  "Education",
  "Contact",
];

export const useStore = create<AppState>((set, get) => ({
  activeSection: 0,
  previousSection: 0,
  isTransitioning: false,
  selectedObject: null,
  detailPanelOpen: false,
  detailContent: null,
  cameraTarget: sectionCameraPositions[0],
  cameraMode: "free",
  loading: true,
  backButtonVisible: false,
  currentSubsection: null,
  masterBallOpen: false,

  setActiveSection: (section) => {
    const state = get();
    if (state.isTransitioning || section === state.activeSection) return;
    set({
      previousSection: state.activeSection,
      activeSection: section,
      isTransitioning: true,
      selectedObject: null,
      detailPanelOpen: false,
      detailContent: null,
      backButtonVisible: false,
      currentSubsection: null,
      cameraTarget: sectionCameraPositions[section],
      cameraMode: "cinematic",
    });
    setTimeout(() => {
      set({ isTransitioning: false, cameraMode: "free" });
    }, 1500);
  },

  setTransitioning: (v) => set({ isTransitioning: v }),

  selectObject: (id, content) =>
    set({
      selectedObject: id,
      detailContent: content || null,
      detailPanelOpen: !!content,
      backButtonVisible: !!content,
    }),

  setDetailPanelOpen: (v) => set({ detailPanelOpen: v }),

  setCameraTarget: (pos, lookAt) => set({ cameraTarget: { position: pos, lookAt } }),

  setCameraMode: (mode) => set({ cameraMode: mode }),

  setLoading: (v) => set({ loading: v }),

  setBackButtonVisible: (v) => set({ backButtonVisible: v }),

  setCurrentSubsection: (sub) => set({ currentSubsection: sub }),

  setMasterBallOpen: (v) => set({ masterBallOpen: v }),

  goBack: () => {
    set({
      selectedObject: null,
      detailPanelOpen: false,
      detailContent: null,
      backButtonVisible: false,
      currentSubsection: null,
      cameraMode: "free",
    });
  },
}));
