export interface EvolutionStage {
  id: string;
  title: string;
  subtitle: string;
  stage: number;
  stageLabel: string;
  rarity: number;
  color: string;
  period?: string;
  roles: { title: string; detail: string }[];
  skills: string[];
}

export interface Achievement {
  id: string;
  title: string;
  category: string;
  organization?: string;
  description: string;
  skills: string[];
  color: string;
}

export interface Project {
  id: string;
  title: string;
  description: string;
  techStack: string[];
  challenges: string;
  solutions: string;
  outcomes: string;
  color: string;
}

export interface Skill {
  id: string;
  name: string;
  brightness: number;
  cluster: string;
}

export interface Experience {
  id: string;
  title: string;
  subtitle: string;
  period: string;
  location: string;
  color: string;
  objects: { name: string; description: string }[];
}

export interface EducationBuilding {
  id: string;
  title: string;
  color: string;
  content: {
    description?: string;
    period?: string;
    degree?: string;
    location?: string;
    status?: string;
    focus?: string;
    activities?: string[];
    skills?: string[];
    modules?: string[];
    areas?: { title: string; detail: string }[];
    topics?: string[];
  };
}

export const profile = {
  name: "KIAGUS ARIF RAHMAN",
  role: "AI & Data Science Builder",
  title: "System Analyst",
  tagline: "Competition Champion",
  email: "Arifkiagus577@gmail.com",
  linkedin: "linkedin.com/in/Kiagusarifrahman",
  github: "github.com/Akskuy",
  phone: "085175376593",
  location: "Tangerang Selatan, Indonesia",
  summary:
    "Undergraduate Data Science student with strong foundations in statistics, data systems, and AI problem formulation. Experienced in both individual and team-based work involving data processing, system design, and web-based solution implementation. Accustomed to building end-to-end data workflows aligned with user needs and decision-making objectives.",
};

export const evolutionStages: EvolutionStage[] = [
  {
    id: "content-creator",
    title: "CONTENT CREATOR",
    subtitle: "Media Production & Editing",
    stage: 1,
    stageLabel: "STAGE I",
    rarity: 2,
    color: "#00f0ff",
    period: "Dec 2025 - Present",
    roles: [
      {
        title: "Video Editor — Dessydiniyanti",
        detail: "Edited short-form and long-form video content. Maintained visual structure, pacing, and typography. Delivered content under tight deadlines.",
      },
      {
        title: "Clipper/Content Editor — TernakUang",
        detail: "Performance-oriented short-form video clipping. Identified high-impact moments aligned with audience engagement. Adapted content pacing and structure for platform-specific distribution.",
      },
    ],
    skills: ["Video Editing", "Content Strategy", "Social Media", "Audience Engagement"],
  },
  {
    id: "customer-service",
    title: "CUSTOMER SERVICE",
    subtitle: "Client Relations & Transactions",
    stage: 2,
    stageLabel: "STAGE II",
    rarity: 2,
    color: "#4a9eff",
    period: "Sep 2019 - Jan 2021",
    roles: [
      {
        title: "Customer Service — GTmurah",
        detail: "Handled customer communication and transaction flow. Ensured account trust and transaction accuracy. Maintained basic records of transactions and orders.",
      },
    ],
    skills: ["Customer Relations", "Transaction Management", "Communication", "Trust Building"],
  },
  {
    id: "community-leader",
    title: "COMMUNITY LEADER",
    subtitle: "Regional Coordination & Engagement",
    stage: 3,
    stageLabel: "STAGE III",
    rarity: 3,
    color: "#00d4aa",
    period: "Sep 2023 - Sep 2024",
    roles: [
      {
        title: "Head — Forum Daerah Tangerang Raya (BENEFITS) ITS",
        detail: "Led regional student coordination and activities. Managed internal communication and member engagement. Represented regional interests within institutional forums.",
      },
    ],
    skills: ["Leadership", "Community Building", "Event Coordination", "Public Relations"],
  },
  {
    id: "ai-leader",
    title: "AI LEADER",
    subtitle: "Head of Data Science & AI",
    stage: 4,
    stageLabel: "STAGE IV",
    rarity: 4,
    color: "#00f0ff",
    period: "Mar 2023 - Mar 2024",
    roles: [
      {
        title: "Head of DSAI — Avalon AI Community, ITS",
        detail: "Led cross-functional technical teams (Data, AI, Software, UI/UX). Defined technical direction and quality standards for projects. Mentored members from problem formulation to solution delivery. Ensured robustness and feasibility of final outputs.",
      },
    ],
    skills: ["AI Leadership", "Team Management", "Technical Direction", "Mentorship", "Project Quality"],
  },
  {
    id: "data-scientist",
    title: "DATA SCIENTIST",
    subtitle: "Statistical Analysis & Survey Design",
    stage: 5,
    stageLabel: "STAGE V",
    rarity: 3,
    color: "#4a9eff",
    period: "Mar 2024 - Jun 2024",
    roles: [
      {
        title: "Survey Analytics — Department of Statistics, ITS",
        detail: "Conducted structured surveys under Department of Statistics ITS. Designed survey instruments based on company-specific requirements. Processed, cleaned, and validated raw survey data. Structured and packaged datasets into business-ready data products.",
      },
    ],
    skills: ["Statistical Modeling", "Survey Design", "Data Processing", "Data Packaging", "Data Quality"],
  },
  {
    id: "system-analyst",
    title: "SYSTEM ANALYST",
    subtitle: "Workflow Automation & System Design",
    stage: 6,
    stageLabel: "STAGE VI",
    rarity: 3,
    color: "#9b59b6",
    period: "Oct 2025 - Present",
    roles: [
      {
        title: "Data & System Analyst — Independent Team Project",
        detail: "Processed, cleaned, and structured datasets for practical use. Packaged data into business-ready information products. Built a pre-release automated clipping website. Designed workflow automation from link input to upload process.",
      },
    ],
    skills: ["System Analysis", "Workflow Automation", "Web Development", "Data Structuring", "Backend"],
  },
  {
    id: "competition-champion",
    title: "COMPETITION CHAMPION",
    subtitle: "Award-Winning Innovation",
    stage: 7,
    stageLabel: "STAGE VII",
    rarity: 5,
    color: "#ffd700",
    roles: [
      {
        title: "Champion — COMPFEST 16 (AI Innovation Challenge)",
        detail: "Won first place in the AI Innovation Challenge at Indonesia's largest student IT festival.",
      },
      {
        title: "Runner-up — ICONIC IT UI/UX Competition",
        detail: "Achieved second place demonstrating excellence in UI/UX design and research.",
      },
      {
        title: "Best 2nd Product (Top 2 of 600+) — Bangkit Program",
        detail: "Ranked Top 2 out of 600+ products. Program backed by Google, GoTo, and Traveloka.",
      },
    ],
    skills: ["Innovation", "Competitive Problem Solving", "UI/UX Design", "AI Solutions", "Product Development"],
  },
  {
    id: "future-evolution",
    title: "FUTURE EVOLUTION",
    subtitle: "???",
    stage: 8,
    stageLabel: "FINAL FORM",
    rarity: 6,
    color: "#ff6b9d",
    roles: [
      {
        title: "The Journey Continues...",
        detail: "Currently pursuing Undergraduate Data Science, Expected Graduation 2027. Exploring AI Research, Advanced Analytics, System Architecture, and Product Innovation.",
      },
    ],
    skills: ["AI Research", "Advanced Analytics", "System Architecture", "Product Innovation"],
  },
];

export const achievements: Achievement[] = [
  {
    id: "compfest",
    title: "Champion — COMPFEST 16",
    category: "AI Innovation Challenge",
    description:
      "Won first place in the AI Innovation Challenge at COMPFEST 16, Indonesia's largest student IT festival. Competed against top university teams to develop an innovative AI solution.",
    skills: ["AI Innovation", "Competitive Problem Solving", "Team Collaboration", "Technical Presentation"],
    color: "#00f0ff",
  },
  {
    id: "bangkit",
    title: "Best 2nd Product — Bangkit Program",
    category: "Product Innovation",
    organization: "Google, GoTo, Traveloka",
    description:
      "Ranked Top 2 out of 600+ products in the Bangkit Program, a prestigious technology capstone program backed by Google, GoTo, and Traveloka. Product recognized for innovation, technical execution, and market viability.",
    skills: ["Product Development", "Market Viability", "Technical Execution", "Entrepreneurship"],
    color: "#00d4aa",
  },
  {
    id: "iconic",
    title: "Runner-up — ICONIC IT",
    category: "UI/UX Competition",
    description:
      "Achieved second place in the ICONIC IT UI/UX Competition, demonstrating excellence in user interface design, user experience research, and design system implementation.",
    skills: ["UI/UX Design", "Design Systems", "User Research", "Visual Design"],
    color: "#9b59b6",
  },
];

export const projects: Project[] = [
  {
    id: "clipping-website",
    title: "Automated Clipping Website",
    description:
      "Pre-release automated video clipping website with end-to-end workflow from link input to upload process. Designed automation pipeline that processes video links, extracts highlights, and publishes ready-to-use clips.",
    techStack: ["Python", "FFmpeg", "Web Automation", "Backend API"],
    challenges: "Building reliable video processing pipeline, handling various video formats, optimizing processing speed",
    solutions: "Modular architecture with format adapters, async processing queue, cached intermediate files",
    outcomes: "Reduced manual clipping time by 90%, automated entire workflow from input to publish",
    color: "#00f0ff",
  },
  {
    id: "survey-analytics",
    title: "Survey Analytics Platform",
    description:
      "Structured survey system developed under Department of Statistics ITS. Designed survey instruments based on company requirements, processed raw data, and packaged into business-ready analytical products.",
    techStack: ["R", "Python", "Statistical Analysis", "Survey Methodology"],
    challenges: "Designing unbiased survey instruments, cleaning inconsistent raw data, meeting specific company reporting needs",
    solutions: "Rigorous survey validation process, automated data cleaning pipeline, customizable reporting templates",
    outcomes: "Delivered clean, structured datasets and analytical reports for external company stakeholders",
    color: "#4a9eff",
  },
  {
    id: "registration-website",
    title: "Registration & Data Collection Website",
    description:
      "Built functional websites for event registration and data collection. Implemented form validation, data storage, and administrative dashboard for managing submissions.",
    techStack: ["HTML/CSS/JS", "PHP", "MySQL", "Form Validation"],
    challenges: "Ensuring data integrity, preventing duplicate submissions, creating user-friendly forms",
    solutions: "Server-side validation, unique constraint database design, progressive form UX",
    outcomes: "Successfully collected and managed hundreds of registrations with zero data loss",
    color: "#00d4aa",
  },
  {
    id: "data-collection",
    title: "Data Collection Platform",
    description:
      "End-to-end data collection and packaging system. Processes raw inputs through validation, transformation, and structuring into business-ready information products.",
    techStack: ["Python", "Pandas", "SQL", "Data Validation"],
    challenges: "Handling diverse data sources, maintaining data consistency, scalable processing",
    solutions: "Schema validation framework, automated quality checks, batch processing architecture",
    outcomes: "Consistent, high-quality data products delivered to business stakeholders",
    color: "#4a9eff",
  },
  {
    id: "business-products",
    title: "Business-Ready Data Products",
    description:
      "Packaged analytical results based on company requirements into finalized, deliverable data outputs. Ensured data consistency, analytical usability, and alignment with business decision-making objectives.",
    techStack: ["R", "Python", "Excel", "Reporting", "Data Visualization"],
    challenges: "Translating technical analysis into business language, meeting diverse stakeholder needs",
    solutions: "Executive summary templates, interactive dashboards, multiple output formats",
    outcomes: "Stakeholders received actionable insights in accessible, professional formats",
    color: "#9b59b6",
  },
];

export const skills: Skill[] = [
  // AI Cluster
  { id: "ml", name: "Machine Learning", brightness: 1.0, cluster: "ai" },
  { id: "dl", name: "Deep Learning", brightness: 0.9, cluster: "ai" },
  { id: "ai-problem", name: "AI Problem Formulation", brightness: 1.0, cluster: "ai" },
  { id: "nlp", name: "NLP", brightness: 0.8, cluster: "ai" },
  { id: "cv", name: "Computer Vision", brightness: 0.7, cluster: "ai" },
  { id: "tf", name: "TensorFlow/PyTorch", brightness: 0.8, cluster: "ai" },
  // Statistics Cluster
  { id: "stat-model", name: "Statistical Modeling", brightness: 1.0, cluster: "statistics" },
  { id: "prob-reason", name: "Probabilistic Reasoning", brightness: 0.9, cluster: "statistics" },
  { id: "multivariate", name: "Multivariate Analysis", brightness: 0.8, cluster: "statistics" },
  { id: "survey", name: "Survey Design", brightness: 0.9, cluster: "statistics" },
  { id: "data-proc", name: "Data Processing", brightness: 1.0, cluster: "statistics" },
  { id: "data-viz", name: "Data Visualization", brightness: 0.8, cluster: "statistics" },
  // Database Cluster
  { id: "db-design", name: "Database Design", brightness: 1.0, cluster: "database" },
  { id: "schema", name: "Data Schema Structuring", brightness: 0.9, cluster: "database" },
  { id: "query-opt", name: "Query Optimization", brightness: 0.8, cluster: "database" },
  { id: "pipelines", name: "Data Pipelines", brightness: 1.0, cluster: "database" },
  { id: "sql-nosql", name: "SQL/NoSQL", brightness: 0.9, cluster: "database" },
  { id: "etl", name: "ETL Processes", brightness: 0.8, cluster: "database" },
  // Systems Cluster
  { id: "sys-analysis", name: "System Analysis", brightness: 1.0, cluster: "systems" },
  { id: "workflow", name: "Workflow Automation", brightness: 0.9, cluster: "systems" },
  { id: "backend", name: "Backend Development", brightness: 0.8, cluster: "systems" },
  { id: "web-dev", name: "Web Development", brightness: 0.9, cluster: "systems" },
  { id: "data-collect", name: "Data Collection Systems", brightness: 0.8, cluster: "systems" },
  { id: "sys-arch", name: "System Architecture", brightness: 0.7, cluster: "systems" },
  // Leadership Cluster
  { id: "team-lead", name: "Team Leadership", brightness: 1.0, cluster: "leadership" },
  { id: "tech-dir", name: "Technical Direction", brightness: 0.9, cluster: "leadership" },
  { id: "mentorship", name: "Mentorship", brightness: 1.0, cluster: "leadership" },
  { id: "proj-mgmt", name: "Project Management", brightness: 0.8, cluster: "leadership" },
  { id: "collab", name: "Cross-functional Collaboration", brightness: 0.9, cluster: "leadership" },
  { id: "pr", name: "Public Relations", brightness: 0.7, cluster: "leadership" },
];

export const experiences: Experience[] = [
  {
    id: "avalon",
    title: "Avalon AI Headquarters",
    subtitle: "Head of Data Science & AI",
    period: "Mar 2023 - Mar 2024",
    location: "ITS Surabaya",
    color: "#00f0ff",
    objects: [
      { name: "Leadership Console", description: "Led cross-functional technical teams spanning Data, AI, Software, and UI/UX disciplines" },
      { name: "Direction Matrix", description: "Defined technical direction and quality standards for all community projects" },
      { name: "Mentor Station", description: "Mentored members from problem formulation through solution delivery" },
      { name: "Quality Core", description: "Ensured robustness and feasibility of final project outputs" },
    ],
  },
  {
    id: "statistics",
    title: "Statistics Laboratory",
    subtitle: "Survey Analytics & Data Processing",
    period: "Mar 2024 - Jun 2024",
    location: "Department of Statistics, ITS",
    color: "#4a9eff",
    objects: [
      { name: "Survey Terminal", description: "Designed survey instruments based on company-specific requirements" },
      { name: "Data Processor", description: "Processed, cleaned, and validated raw survey data" },
      { name: "Delivery Package", description: "Structured and packaged datasets into business-ready data products" },
      { name: "Quality Scanner", description: "Delivered finalized data outputs ensuring data consistency and analytical usability" },
    ],
  },
  {
    id: "system",
    title: "System Factory",
    subtitle: "Data & System Analyst",
    period: "Oct 2025 - Present",
    location: "Independent Team Project",
    color: "#9b59b6",
    objects: [
      { name: "Clipping Machine", description: "Built a pre-release automated clipping website for video content processing" },
      { name: "Workflow Conveyor", description: "Designed workflow automation from link input to upload process" },
      { name: "Data Forge", description: "Processed, cleaned, and structured datasets for practical use" },
      { name: "Registration Portal", description: "Built functional websites for registration and data collection" },
    ],
  },
  {
    id: "media",
    title: "Media Studio",
    subtitle: "Video & Content Editor",
    period: "Dec 2025 - Present",
    location: "Remote",
    color: "#ff4d6d",
    objects: [
      { name: "Editing Suite", description: "Edited short-form and long-form video content with visual structure and pacing" },
      { name: "Content Forge", description: "Performance-oriented short-form video clipping for audience engagement" },
      { name: "Performance Dashboard", description: "Identified high-impact moments aligned with audience engagement metrics" },
      { name: "Clip Organizer", description: "Adapted content pacing and structure for platform-specific distribution" },
    ],
  },
  {
    id: "customer",
    title: "Customer Hub",
    subtitle: "Customer Service",
    period: "Sep 2019 - Jan 2021",
    location: "GTmurah — Remote",
    color: "#ffd700",
    objects: [
      { name: "Communication Desk", description: "Handled customer communication and transaction flow" },
      { name: "Transaction Vault", description: "Ensured account trust and transaction accuracy" },
      { name: "Record Archive", description: "Maintained basic records of transactions and orders" },
      { name: "Trust Shield", description: "Built customer trust through reliable and consistent service" },
    ],
  },
];

export const educationBuildings: EducationBuilding[] = [
  {
    id: "main-hall",
    title: "INSTITUT TEKNOLOGI SEPULUH NOPEMBER",
    color: "#ffd700",
    content: {
      degree: "Bachelor of Communication",
      period: "Aug 2023 - Jul 2027 (Expected)",
      location: "Surabaya, Indonesia",
      status: "Undergraduate Data Science Student",
      focus: "Statistics, Data Systems, AI Problem Formulation",
    },
  },
  {
    id: "skills-center",
    title: "WORKSHOPS, TRAINING & WEBINARS",
    color: "#00f0ff",
    content: {
      description: "Actively participates in 10+ campus events including workshops, skills training workshops, training programs, and webinars",
      areas: [
        { title: "Workshops", detail: "Hands-on practical learning sessions" },
        { title: "Training Programs", detail: "Structured technical and professional development" },
        { title: "Webinars", detail: "Emerging technology and industry trend seminars" },
      ],
      topics: ["AI & Machine Learning", "Data Science", "Technology Trends", "Industry Insights", "Professional Skills"],
      skills: ["Workshop Facilitation", "Hands-on Learning", "Peer Collaboration", "Industry Readiness"],
    },
  },
  {
    id: "tradewithsuli",
    title: "TRADEWITHSULI MODULES",
    color: "#9b59b6",
    content: {
      period: "2025",
      description: "Independent structured learning on market dynamics, volatility analysis, and probabilistic risk management",
      modules: ["Market Dynamics", "Volatility Analysis", "Probabilistic Risk Management"],
      skills: ["Financial Analysis", "Risk Assessment", "Market Modeling"],
    },
  },
  {
    id: "activities",
    title: "CAMPUS ACTIVITIES & LEADERSHIP",
    color: "#00d4aa",
    content: {
      description: "Participated in 10+ campus webinars and skills training workshops",
      activities: [
        "Business Orientation Camp Cluster Head — 6 months",
        "Values-In-Action (VIA) Ambassador — CCA Tennis — 6 months",
        "Executive Committee of Co-Curricular Activity (Tennis)",
      ],
      skills: ["Event Leadership", "Sports Commitment", "Values Integration", "Team Coordination"],
    },
  },
];
