import { useRef, useState } from "react";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { useStore } from "@/store/useStore";
import { achievements } from "@/data/resume";
import type { DetailContent } from "@/store/useStore";
import * as THREE from "three";

const trophyPositions: [number, number, number][] = [
  [0, 0, 0],
  [-4, 0, 2],
  [4, 0, 2],
];

const pedestalHeights = [2.0, 1.5, 1.5];
const trophyScales = [1.5, 1.2, 1.2];

function DustParticles({ color }: { color: string }) {
  const count = 50;
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const dummy = new THREE.Object3D();

  const particles = useRef(
    Array.from({ length: count }, () => ({
      x: (Math.random() - 0.5) * 3,
      y: Math.random() * 5,
      z: (Math.random() - 0.5) * 3,
      speed: 0.005 + Math.random() * 0.01,
    }))
  );

  useFrame(() => {
    if (!meshRef.current) return;
    particles.current.forEach((p, i) => {
      p.y -= p.speed;
      if (p.y < 0) p.y = 5;
      dummy.position.set(p.x, p.y, p.z);
      dummy.scale.setScalar(0.01 + Math.random() * 0.01);
      dummy.updateMatrix();
      meshRef.current!.setMatrixAt(i, dummy.matrix);
    });
    meshRef.current.instanceMatrix.needsUpdate = true;
  });

  return (
    <instancedMesh ref={meshRef} args={[undefined, undefined, count]}>
      <sphereGeometry args={[1, 4, 4]} />
      <meshBasicMaterial color={color} transparent opacity={0.6} />
    </instancedMesh>
  );
}

function VolumetricLight({ position, color }: { position: [number, number, number]; color: string }) {
  return (
    <mesh position={position}>
      <coneGeometry args={[1.5, 8, 16, 1, true]} />
      <meshBasicMaterial
        color={color}
        transparent
        opacity={0.05}
        side={THREE.DoubleSide}
        blending={THREE.AdditiveBlending}
        depthWrite={false}
      />
    </mesh>
  );
}

function Trophy({
  achievement,
  position,
  pedestalHeight,
  scale,
  index,
}: {
  achievement: (typeof achievements)[0];
  position: [number, number, number];
  pedestalHeight: number;
  scale: number;
  index: number;
}) {
  const [hovered, setHovered] = useState(false);
  const groupRef = useRef<THREE.Group>(null);
  const { selectObject } = useStore();

  const handleClick = () => {
    const content: DetailContent = {
      type: "achievement",
      id: achievement.id,
      title: achievement.title,
      subtitle: achievement.category,
      description: achievement.description,
      tags: achievement.skills,
      meta: achievement.organization
        ? { Organization: achievement.organization }
        : undefined,
    };
    selectObject(achievement.id, content);
  };

  useFrame((state) => {
    if (groupRef.current) {
      const trophyGroup = groupRef.current.children[1] as THREE.Group;
      if (trophyGroup) {
        trophyGroup.rotation.y = state.clock.elapsedTime * 0.3 + index * 2;
        trophyGroup.position.y = pedestalHeight + 0.5 + Math.sin(state.clock.elapsedTime + index) * 0.05;
      }
    }
  });

  return (
    <group position={position}>
      {/* Pedestal */}
      <mesh position={[0, pedestalHeight / 2, 0]}>
        <cylinderGeometry args={[0.8, 1, pedestalHeight, 8]} />
        <meshStandardMaterial
          color="#111"
          metalness={0.8}
          roughness={0.2}
        />
      </mesh>
      {/* Gold trim */}
      <mesh position={[0, pedestalHeight - 0.05, 0]}>
        <cylinderGeometry args={[0.82, 0.82, 0.05, 8]} />
        <meshStandardMaterial
          color="#ffd700"
          metalness={1}
          roughness={0.1}
        />
      </mesh>

      {/* Trophy Group */}
      <group ref={groupRef}>
        <group
          scale={scale}
          onClick={handleClick}
          onPointerOver={() => {
            setHovered(true);
            document.body.style.cursor = "pointer";
          }}
          onPointerOut={() => {
            setHovered(false);
            document.body.style.cursor = "default";
          }}
        >
          {/* Trophy Body */}
          <mesh position={[0, pedestalHeight + 1, 0]}>
            <cylinderGeometry args={[0.15, 0.3, 1.2, 8]} />
            <meshStandardMaterial
              color={achievement.color}
              metalness={0.9}
              roughness={0.1}
              emissive={achievement.color}
              emissiveIntensity={hovered ? 0.3 : 0.1}
            />
          </mesh>
          {/* Trophy Cup */}
          <mesh position={[0, pedestalHeight + 1.7, 0]}>
            <cylinderGeometry args={[0.4, 0.15, 0.4, 8]} />
            <meshStandardMaterial
              color={achievement.color}
              metalness={0.9}
              roughness={0.1}
              emissive={achievement.color}
              emissiveIntensity={0.2}
            />
          </mesh>
          {/* Handles */}
          {[-0.4, 0.4].map((x) => (
            <mesh key={x} position={[x, pedestalHeight + 1.5, 0]}>
              <torusGeometry args={[0.15, 0.04, 8, 16, Math.PI]} />
              <meshStandardMaterial
                color="#ffd700"
                metalness={1}
                roughness={0.1}
              />
            </mesh>
          ))}
          {/* Star on top */}
          <mesh position={[0, pedestalHeight + 2, 0]}>
            <octahedronGeometry args={[0.15, 0]} />
            <meshStandardMaterial
              color="#ffd700"
              emissive="#ffd700"
              emissiveIntensity={0.5}
              metalness={1}
            />
          </mesh>
        </group>
      </group>

      {/* Volumetric light */}
      <VolumetricLight
        position={[position[0], 4, position[2]]}
        color={achievement.color}
      />

      {/* Dust particles */}
      <group position={[position[0], 0, position[2]]}>
        <DustParticles color={achievement.color} />
      </group>

      {/* Label */}
      <Text
        position={[position[0], pedestalHeight + 2.8, position[2]]}
        fontSize={0.2}
        color={hovered ? "#ffffff" : achievement.color}
        anchorX="center"
        anchorY="middle"
        font="https://fonts.gstatic.com/s/rajdhani/v15/LDI2apCSOBg7SHTQkAwBqMcVabBF.woff2"
      >
        {achievement.title}
      </Text>
    </group>
  );
}

export default function AchievementSection() {
  return (
    <group>
      {/* Dramatic lighting */}
      <spotLight
        position={[0, 8, 0]}
        angle={0.5}
        penumbra={1}
        intensity={2}
        color="#ffd700"
        castShadow
      />
      <pointLight position={[-4, 5, 2]} intensity={0.6} color="#00d4aa" />
      <pointLight position={[4, 5, 2]} intensity={0.6} color="#9b59b6" />
      <ambientLight intensity={0.1} color="#ffd700" />

      {/* Reflective floor */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]}>
        <planeGeometry args={[30, 30]} />
        <meshStandardMaterial
          color="#050508"
          metalness={0.9}
          roughness={0.1}
        />
      </mesh>

      {/* Title */}
      <Text
        position={[-5, 5, 0]}
        fontSize={0.45}
        color="#ffd700"
        anchorX="left"
        anchorY="middle"
        font="https://fonts.gstatic.com/s/rajdhani/v15/LDI2apCSOBg7SHTQkAwBqMcVabBF.woff2"
      >
        ACHIEVEMENT HALL
      </Text>
      <Text
        position={[-5, 4.4, 0]}
        fontSize={0.2}
        color="#6b7280"
        anchorX="left"
        anchorY="middle"
      >
        Honors & Recognition
      </Text>

      {/* Trophies */}
      {achievements.map((achievement, i) => (
        <Trophy
          key={achievement.id}
          achievement={achievement}
          position={trophyPositions[i]}
          pedestalHeight={pedestalHeights[i]}
          scale={trophyScales[i]}
          index={i}
        />
      ))}
    </group>
  );
}
