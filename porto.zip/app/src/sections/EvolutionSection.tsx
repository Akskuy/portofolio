import { useRef, useMemo } from "react";
import { Float, Text, Html } from "@react-three/drei";
import { useStore } from "@/store/useStore";
import { evolutionStages } from "@/data/resume";
import type { DetailContent } from "@/store/useStore";
import * as THREE from "three";

const cardPositions = [
  [-4, 1, 0], [-1.5, -0.5, 0], [1.5, 0.5, 0], [4, -1, 0],
  [-3, -1, -2], [0, 1, -2], [3, -0.5, -2], [0, 2, -1],
];

function EvolutionCard({
  stage,
  position,
  index,
}: {
  stage: (typeof evolutionStages)[0];
  position: number[];
  index: number;
}) {
  const meshRef = useRef<THREE.Mesh>(null);
  const { selectObject } = useStore();

  const handleClick = () => {
    const content: DetailContent = {
      type: "evolution",
      id: stage.id,
      title: stage.title,
      subtitle: stage.subtitle,
      description: stage.period
        ? `Period: ${stage.period}`
        : undefined,
      items: stage.roles.map((r) => ({
        label: r.title,
        value: r.detail,
      })),
      tags: stage.skills,
    };
    selectObject(stage.id, content);
  };

  const initialRotation = useMemo(
    () => [
      (Math.random() - 0.5) * 0.3,
      (Math.random() - 0.5) * 0.3,
      (Math.random() - 0.5) * 0.1,
    ],
    []
  );

  return (
    <Float
      speed={2 + index * 0.3}
      rotationIntensity={0.2}
      floatIntensity={0.4}
      floatingRange={[-0.15, 0.15]}
    >
      <group position={position as [number, number, number]}>
        <mesh
          ref={meshRef}
          rotation={initialRotation as [number, number, number]}
          onClick={handleClick}
          onPointerOver={() => (document.body.style.cursor = "pointer")}
          onPointerOut={() => (document.body.style.cursor = "default")}
        >
          <boxGeometry args={[2.2, 3.0, 0.06]} />
          <meshStandardMaterial
            color="#1a2342"
            metalness={0.6}
            roughness={0.3}
            emissive={stage.color}
            emissiveIntensity={0.08}
          />
        </mesh>
        {/* Border glow */}
        <mesh position={[0, 0, 0.035]}>
          <planeGeometry args={[2.18, 2.98]} />
          <meshBasicMaterial
            color={stage.color}
            transparent
            opacity={0.2}
          />
        </mesh>
        {/* Card Content */}
        <Html
          position={[0, 0, 0.04]}
          transform
          occlude
          style={{
            width: "220px",
            height: "300px",
            pointerEvents: "none",
          }}
        >
          <div className="w-full h-full flex flex-col items-center justify-between py-4 px-3 relative">
            {/* Rarity indicator */}
            <div className="absolute top-2 left-2 flex gap-0.5">
              {Array.from({ length: stage.rarity }).map((_, i) => (
                <span key={i} className="text-xs" style={{ color: stage.color }}>
                  ★
                </span>
              ))}
            </div>
            {/* Card Art Area */}
            <div
              className="w-full h-32 rounded-lg flex items-center justify-center mb-2"
              style={{
                background: `linear-gradient(135deg, ${stage.color}22, ${stage.color}08)`,
                border: `1px solid ${stage.color}44`,
              }}
            >
              <span className="text-4xl opacity-50">
                {index === 0 && "🎬"}
                {index === 1 && "💬"}
                {index === 2 && "🌐"}
                {index === 3 && "🤖"}
                {index === 4 && "📊"}
                {index === 5 && "⚙️"}
                {index === 6 && "🏆"}
                {index === 7 && "🔮"}
              </span>
            </div>
            {/* Title */}
            <div className="text-center w-full">
              <h3
                className="text-sm font-bold text-white leading-tight"
                style={{ fontFamily: "Rajdhani" }}
              >
                {stage.title}
              </h3>
              <p className="text-[10px] text-gray-400 mt-1">{stage.subtitle}</p>
            </div>
            {/* Stage Badge */}
            <div className="flex items-center justify-between w-full mt-2">
              <span
                className="text-[9px] px-2 py-0.5 rounded-full"
                style={{
                  background: `${stage.color}22`,
                  color: stage.color,
                  border: `1px solid ${stage.color}44`,
                  fontFamily: "Rajdhani",
                }}
              >
                {stage.stageLabel}
              </span>
            </div>
          </div>
        </Html>
      </group>
    </Float>
  );
}

export default function EvolutionSection() {
  return (
    <group>
      <pointLight position={[0, 5, 5]} intensity={1} color="#ffffff" />
      <pointLight position={[-5, 3, 3]} intensity={0.4} color="#00f0ff" />
      <pointLight position={[5, 3, 3]} intensity={0.4} color="#00d4aa" />
      <pointLight position={[0, -3, 5]} intensity={0.4} color="#4a9eff" />
      <pointLight position={[3, -3, 2]} intensity={0.4} color="#ffd700" />

      {/* Section Title */}
      <Text
        position={[-5, 4, 0]}
        fontSize={0.4}
        color="#ffffff"
        anchorX="left"
        anchorY="middle"
        font="https://fonts.gstatic.com/s/rajdhani/v15/LDI2apCSOBg7SHTQkAwBqMcVabBF.woff2"
      >
        EVOLUTION GALLERY
      </Text>
      <Text
        position={[-5, 3.4, 0]}
        fontSize={0.2}
        color="#6b7280"
        anchorX="left"
        anchorY="middle"
        font="https://fonts.gstatic.com/s/rajdhani/v15/LDI2apCSOBg7SHTQkAwBqMcVabBF.woff2"
      >
        Choose any card to discover
      </Text>

      {evolutionStages.map((stage, i) => (
        <EvolutionCard
          key={stage.id}
          stage={stage}
          position={cardPositions[i]}
          index={i}
        />
      ))}
    </group>
  );
}
