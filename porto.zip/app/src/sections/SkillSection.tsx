import { useRef, useMemo, useState } from "react";
import { useFrame } from "@react-three/fiber";
import { Text, Stars } from "@react-three/drei";
import { useStore } from "@/store/useStore";
import { skills } from "@/data/resume";
import type { DetailContent } from "@/store/useStore";
import * as THREE from "three";

const clusterCenters: Record<string, [number, number, number, string]> = {
  ai: [5, 3, -3, "#00f0ff"],
  statistics: [-5, 3, -3, "#4a9eff"],
  database: [5, -2, -3, "#00d4aa"],
  systems: [-5, -2, -3, "#9b59b6"],
  leadership: [2, 0, -2, "#ffd700"],
};

function ConstellationLine({
  start,
  end,
  color,
  hovered,
}: {
  start: [number, number, number];
  end: [number, number, number];
  color: string;
  hovered: boolean;
}) {
  const lineRef = useRef<THREE.Line>(null);

  useMemo(() => {
    if (lineRef.current) {
      const points = [new THREE.Vector3(...start), new THREE.Vector3(...end)];
      lineRef.current.geometry.setFromPoints(points);
    }
  }, [start, end]);

  return (
    <primitive object={new THREE.Line()} ref={lineRef}>
      <lineBasicMaterial
        color={color}
        transparent
        opacity={hovered ? 0.6 : 0.15}
        blending={THREE.AdditiveBlending}
      />
    </primitive>
  );
}

function SkillStar({
  skill,
  position,
  onHover,
  onLeave,
  onClick,
  isHovered,
}: {
  skill: (typeof skills)[0];
  position: [number, number, number];
  onHover: () => void;
  onLeave: () => void;
  onClick: () => void;
  isHovered: boolean;
}) {
  const meshRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (meshRef.current) {
      const pulse = Math.sin(state.clock.elapsedTime * 2 + position[0] * 10) * 0.2 + 1;
      const scale = (skill.brightness * 0.8 + 0.3) * pulse * (isHovered ? 1.5 : 1);
      meshRef.current.scale.setScalar(scale);
    }
  });

  const clusterInfo = clusterCenters[skill.cluster];
  const color = clusterInfo ? clusterInfo[3] : "#ffffff";

  return (
    <group position={position}>
      <mesh
        ref={meshRef}
        onPointerOver={() => {
          onHover();
          document.body.style.cursor = "pointer";
        }}
        onPointerOut={() => {
          onLeave();
          document.body.style.cursor = "default";
        }}
        onClick={onClick}
      >
        <sphereGeometry args={[0.15, 8, 8]} />
        <meshStandardMaterial
          color={color}
          emissive={color}
          emissiveIntensity={isHovered ? 1.5 : skill.brightness * 0.8}
          transparent
          opacity={0.9}
        />
      </mesh>
      {/* Glow ring */}
      <mesh>
        <ringGeometry args={[0.2, 0.25, 16]} />
        <meshBasicMaterial
          color={color}
          transparent
          opacity={isHovered ? 0.4 : 0.1}
          side={THREE.DoubleSide}
        />
      </mesh>
      {/* Label (only when hovered) */}
      {isHovered && (
        <Text
          position={[0, 0.4, 0]}
          fontSize={0.2}
          color="#ffffff"
          anchorX="center"
          anchorY="middle"
          font="https://fonts.gstatic.com/s/rajdhani/v15/LDI2apCSOBg7SHTQkAwBqMcVabBF.woff2"
        >
          {skill.name}
        </Text>
      )}
    </group>
  );
}

function GalaxyCore() {
  const meshRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (meshRef.current) {
      const intensity = 0.8 + Math.sin(state.clock.elapsedTime * 2) * 0.2;
      const mat = meshRef.current.material as THREE.MeshStandardMaterial;
      mat.emissiveIntensity = intensity;
    }
  });

  return (
    <mesh ref={meshRef}>
      <sphereGeometry args={[0.5, 16, 16]} />
      <meshStandardMaterial
        color="#ffffff"
        emissive="#ffffff"
        emissiveIntensity={1}
        transparent
        opacity={0.9}
      />
    </mesh>
  );
}

function SkillCluster({
  clusterName,
  clusterSkills,
  hoveredStar,
  onStarHover,
  onStarLeave,
  onStarClick,
}: {
  clusterName: string;
  clusterSkills: (typeof skills);
  hoveredStar: string | null;
  onStarHover: (id: string) => void;
  onStarLeave: () => void;
  onStarClick: (skill: (typeof skills)[0]) => void;
}) {
  const center = clusterCenters[clusterName];
  if (!center) return null;

  const positions = useMemo(() => {
    return clusterSkills.map((_, i) => {
      const angle = (i / clusterSkills.length) * Math.PI * 2 + Math.random() * 0.5;
      const radius = 1.5 + Math.random() * 1.5;
      return [
        center[0] + Math.cos(angle) * radius,
        center[1] + Math.sin(angle * 1.5) * 1.2,
        center[2] + Math.sin(angle) * radius * 0.5,
      ] as [number, number, number];
    });
  }, [clusterSkills, center]);

  const clusterColor = center[3];

  return (
    <group>
      {/* Cluster label */}
      <Text
        position={[center[0], center[1] + 2.5, center[2]]}
        fontSize={0.3}
        color={clusterColor}
        anchorX="center"
        anchorY="middle"
        font="https://fonts.gstatic.com/s/rajdhani/v15/LDI2apCSOBg7SHTQkAwBqMcVabBF.woff2"
      >
        {clusterName.toUpperCase()}
      </Text>
      {/* Stars */}
      {clusterSkills.map((skill, i) => (
        <SkillStar
          key={skill.id}
          skill={skill}
          position={positions[i]}
          isHovered={hoveredStar === skill.id}
          onHover={() => onStarHover(skill.id)}
          onLeave={onStarLeave}
          onClick={() => onStarClick(skill)}
        />
      ))}
      {/* Lines connecting stars in cluster */}
      {positions.map((pos, i) => {
        const nextPos = positions[(i + 1) % positions.length];
        return (
          <ConstellationLine
            key={i}
            start={pos}
            end={nextPos}
            color={clusterColor}
            hovered={hoveredStar ? clusterSkills.some((s) => s.id === hoveredStar) : false}
          />
        );
      })}
    </group>
  );
}

export default function SkillSection() {
  const [hoveredStar, setHoveredStar] = useState<string | null>(null);
  const galaxyRef = useRef<THREE.Group>(null);
  const { selectObject } = useStore();

  const handleStarClick = (skill: (typeof skills)[0]) => {
    const content: DetailContent = {
      type: "skill",
      id: skill.id,
      title: skill.name,
      subtitle: `${skill.cluster.charAt(0).toUpperCase() + skill.cluster.slice(1)} Cluster`,
      description: `Proficiency level: ${Math.round(skill.brightness * 100)}%`,
      tags: [skill.cluster],
    };
    selectObject(skill.id, content);
  };

  const clusters = useMemo(() => {
    const grouped: Record<string, typeof skills> = {};
    skills.forEach((skill) => {
      if (!grouped[skill.cluster]) grouped[skill.cluster] = [];
      grouped[skill.cluster].push(skill);
    });
    return grouped;
  }, []);

  useFrame((state) => {
    if (galaxyRef.current) {
      galaxyRef.current.rotation.y = state.clock.elapsedTime * 0.02;
    }
  });

  return (
    <group>
      <Stars radius={80} depth={60} count={3000} factor={5} saturation={0.3} fade speed={0.5} />
      
      <pointLight position={[0, 0, 0]} intensity={1.5} color="#ffffff" />
      <ambientLight intensity={0.05} />

      {/* Title */}
      <Text
        position={[-7, 5, 0]}
        fontSize={0.4}
        color="#ffffff"
        anchorX="left"
        anchorY="middle"
        font="https://fonts.gstatic.com/s/rajdhani/v15/LDI2apCSOBg7SHTQkAwBqMcVabBF.woff2"
      >
        SKILL CONSTELLATION
      </Text>
      <Text
        position={[-7, 4.4, 0]}
        fontSize={0.2}
        color="#6b7280"
        anchorX="left"
        anchorY="middle"
      >
        Explore the galaxy of expertise
      </Text>

      <group ref={galaxyRef}>
        <GalaxyCore />
        {Object.entries(clusters).map(([clusterName, clusterSkills]) => (
          <SkillCluster
            key={clusterName}
            clusterName={clusterName}
            clusterSkills={clusterSkills}
            hoveredStar={hoveredStar}
            onStarHover={setHoveredStar}
            onStarLeave={() => setHoveredStar(null)}
            onStarClick={handleStarClick}
          />
        ))}
        {/* Cross-cluster constellation lines */}
        <ConstellationLine
          start={[5, 3, -3]}
          end={[2, 0, -2]}
          color="#00f0ff"
          hovered={false}
        />
        <ConstellationLine
          start={[-5, 3, -3]}
          end={[-5, -2, -3]}
          color="#4a9eff"
          hovered={false}
        />
        <ConstellationLine
          start={[5, -2, -3]}
          end={[2, 0, -2]}
          color="#00d4aa"
          hovered={false}
        />
      </group>
    </group>
  );
}
