import { useRef, useState } from "react";
import { useFrame } from "@react-three/fiber";
import { Float, Html, Text } from "@react-three/drei";
import { useStore } from "@/store/useStore";
import { profile } from "@/data/resume";
import { Mail, Linkedin, Github, Download, Phone, X } from "lucide-react";
import * as THREE from "three";

function GoldenParticles() {
  const count = 50;
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const dummy = new THREE.Object3D();
  const particles = useRef(
    Array.from({ length: count }, () => ({
      x: (Math.random() - 0.5) * 10,
      y: Math.random() * 10 + 5,
      z: (Math.random() - 0.5) * 10,
      speed: 0.005 + Math.random() * 0.01,
      size: 0.01 + Math.random() * 0.02,
    }))
  );

  useFrame(() => {
    if (!meshRef.current) return;
    particles.current.forEach((p, i) => {
      p.y -= p.speed;
      if (p.y < -5) p.y = 10;
      dummy.position.set(p.x, p.y, p.z);
      dummy.scale.setScalar(p.size);
      dummy.updateMatrix();
      meshRef.current!.setMatrixAt(i, dummy.matrix);
    });
    meshRef.current.instanceMatrix.needsUpdate = true;
  });

  return (
    <instancedMesh ref={meshRef} args={[undefined, undefined, count]}>
      <sphereGeometry args={[1, 4, 4]} />
      <meshBasicMaterial color="#ffd700" transparent opacity={0.6} />
    </instancedMesh>
  );
}

function MasterBall() {
  const [hovered, setHovered] = useState(false);
  const [isOpening, setIsOpening] = useState(false);
  const topHalfRef = useRef<THREE.Group>(null);
  const bottomHalfRef = useRef<THREE.Group>(null);
  const buttonRef = useRef<THREE.Mesh>(null);
  const { masterBallOpen, setMasterBallOpen } = useStore();

  useFrame((state) => {
    // Gentle floating
    if (topHalfRef.current && bottomHalfRef.current) {
      const parent = topHalfRef.current.parent;
      if (parent) {
        parent.position.y = Math.sin(state.clock.elapsedTime * 0.8) * 0.05;
        parent.rotation.y = state.clock.elapsedTime * 0.05;
      }
    }

    // Opening animation
    if (isOpening && topHalfRef.current && bottomHalfRef.current) {
      topHalfRef.current.rotation.x = THREE.MathUtils.lerp(
        topHalfRef.current.rotation.x,
        -0.5,
        0.05
      );
      topHalfRef.current.position.y = THREE.MathUtils.lerp(
        topHalfRef.current.position.y,
        0.3,
        0.05
      );
      bottomHalfRef.current.rotation.x = THREE.MathUtils.lerp(
        bottomHalfRef.current.rotation.x,
        0.3,
        0.05
      );
      bottomHalfRef.current.position.y = THREE.MathUtils.lerp(
        bottomHalfRef.current.position.y,
        -0.2,
        0.05
      );
    } else if (!isOpening && topHalfRef.current && bottomHalfRef.current) {
      topHalfRef.current.rotation.x = THREE.MathUtils.lerp(
        topHalfRef.current.rotation.x,
        0,
        0.1
      );
      topHalfRef.current.position.y = THREE.MathUtils.lerp(
        topHalfRef.current.position.y,
        0,
        0.1
      );
      bottomHalfRef.current.rotation.x = THREE.MathUtils.lerp(
        bottomHalfRef.current.rotation.x,
        0,
        0.1
      );
      bottomHalfRef.current.position.y = THREE.MathUtils.lerp(
        bottomHalfRef.current.position.y,
        0,
        0.1
      );
    }

    // Button glow
    if (buttonRef.current) {
      const mat = buttonRef.current.material as THREE.MeshStandardMaterial;
      mat.emissiveIntensity = hovered ? 1 : 0.3;
    }
  });

  const handleClick = () => {
    if (!isOpening) {
      setIsOpening(true);
      setMasterBallOpen(true);
    } else {
      setIsOpening(false);
      setMasterBallOpen(false);
    }
  };

  return (
    <Float speed={1} rotationIntensity={0} floatIntensity={0.2}>
      <group>
        {/* Top Half */}
        <group ref={topHalfRef}>
          <mesh onClick={handleClick}>
            <sphereGeometry args={[1.25, 32, 16, 0, Math.PI * 2, 0, Math.PI / 2]} />
            <meshStandardMaterial
              color="#9b59b6"
              metalness={0.7}
              roughness={0.2}
              emissive="#9b59b6"
              emissiveIntensity={0.05}
            />
          </mesh>
        </group>

        {/* Bottom Half */}
        <group ref={bottomHalfRef}>
          <mesh
            onClick={handleClick}
            rotation={[Math.PI, 0, 0]}
            onPointerOver={() => {
              setHovered(true);
              document.body.style.cursor = "pointer";
            }}
            onPointerOut={() => {
              setHovered(false);
              document.body.style.cursor = "default";
            }}
          >
            <sphereGeometry args={[1.25, 32, 16, 0, Math.PI * 2, 0, Math.PI / 2]} />
            <meshStandardMaterial
              color="#e0e0e0"
              metalness={0.3}
              roughness={0.4}
            />
          </mesh>
        </group>

        {/* Center Band */}
        <mesh>
          <cylinderGeometry args={[1.26, 1.26, 0.15, 32]} />
          <meshStandardMaterial color="#1a1a1a" metalness={0.8} roughness={0.2} />
        </mesh>

        {/* Center Button */}
        <mesh ref={buttonRef} position={[0, 0, 1.26]} onClick={handleClick}>
          <circleGeometry args={[0.25, 32]} />
          <meshStandardMaterial
            color="#333"
            emissive="#00f0ff"
            emissiveIntensity={0.3}
            metalness={0.8}
          />
        </mesh>
        <mesh position={[0, 0, 1.27]} onClick={handleClick}>
          <circleGeometry args={[0.12, 32]} />
          <meshBasicMaterial
            color={hovered ? "#00f0ff" : "#555"}
          />
        </mesh>

        {/* Contact Interface (inside ball) */}
        {masterBallOpen && (
          <Html
            position={[0, 0, 0]}
            center
            style={{
              width: "400px",
              height: "400px",
              pointerEvents: "auto",
              perspective: "800px",
            }}
          >
            <div className="w-full h-full flex items-center justify-center">
              <div
                className="relative w-[380px] rounded-2xl p-8"
                style={{
                  background: "rgba(15, 22, 41, 0.9)",
                  backdropFilter: "blur(20px)",
                  border: "1px solid rgba(0, 240, 255, 0.3)",
                  boxShadow: "0 0 60px rgba(0, 240, 255, 0.2)",
                }}
              >
                {/* Close button */}
                <button
                  onClick={handleClick}
                  className="absolute top-4 right-4 w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors"
                >
                  <X className="w-4 h-4 text-white" />
                </button>

                <h2
                  className="text-xl font-bold text-center mb-6"
                  style={{ fontFamily: "Rajdhani", color: "#00f0ff" }}
                >
                  Let&apos;s build something legendary together.
                </h2>

                {/* Contact Links */}
                <div className="space-y-3 mb-6">
                  {[
                    {
                      icon: <Mail className="w-5 h-5" />,
                      text: profile.email,
                      href: `mailto:${profile.email}`,
                    },
                    {
                      icon: <Linkedin className="w-5 h-5" />,
                      text: "LinkedIn Profile",
                      href: `https://${profile.linkedin}`,
                    },
                    {
                      icon: <Github className="w-5 h-5" />,
                      text: "GitHub Profile",
                      href: `https://${profile.github}`,
                    },
                    {
                      icon: <Phone className="w-5 h-5" />,
                      text: profile.phone,
                      href: `tel:${profile.phone}`,
                    },
                    {
                      icon: <Download className="w-5 h-5" />,
                      text: "Download Resume",
                      href: "#",
                      download: true,
                    },
                  ].map((item) => (
                    <a
                      key={item.text}
                      href={item.href}
                      target={item.href.startsWith("http") ? "_blank" : undefined}
                      rel="noopener noreferrer"
                      className="flex items-center gap-3 p-3 rounded-lg bg-white/5 hover:bg-white/10 transition-all group"
                    >
                      <span className="text-cyan-400 group-hover:scale-110 transition-transform">
                        {item.icon}
                      </span>
                      <span className="text-gray-300 text-sm group-hover:text-white transition-colors">
                        {item.text}
                      </span>
                    </a>
                  ))}
                </div>

                {/* Quick Contact Form */}
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    const btn = e.currentTarget.querySelector(
                      "button[type='submit']"
                    ) as HTMLButtonElement;
                    if (btn) {
                      btn.textContent = "Message Sent!";
                      btn.style.background = "#00d4aa";
                      setTimeout(() => {
                        btn.textContent = "Send Message";
                        btn.style.background = "";
                      }, 2000);
                    }
                  }}
                  className="space-y-3"
                >
                  <input
                    type="text"
                    placeholder="Your Name"
                    className="w-full px-4 py-2 rounded-lg bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:outline-none focus:border-cyan-400 text-sm"
                  />
                  <input
                    type="email"
                    placeholder="Your Email"
                    className="w-full px-4 py-2 rounded-lg bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:outline-none focus:border-cyan-400 text-sm"
                  />
                  <textarea
                    placeholder="Your Message"
                    rows={3}
                    className="w-full px-4 py-2 rounded-lg bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:outline-none focus:border-cyan-400 text-sm resize-none"
                  />
                  <button
                    type="submit"
                    className="w-full py-2.5 rounded-full font-semibold text-sm transition-all"
                    style={{
                      background: "#00f0ff",
                      color: "#0a0a0f",
                      fontFamily: "Rajdhani",
                    }}
                  >
                    Send Message
                  </button>
                </form>
              </div>
            </div>
          </Html>
        )}
      </group>
    </Float>
  );
}

export default function ContactSection() {
  return (
    <group>
      {/* Dramatic spotlight */}
      <spotLight
        position={[0, 8, 2]}
        angle={0.4}
        penumbra={1}
        intensity={3}
        color="#ffffff"
        castShadow
      />
      <ambientLight intensity={0.1} />

      {/* Golden particles */}
      <GoldenParticles />

      {/* Title */}
      <Text
        position={[0, 4.5, 0]}
        fontSize={0.35}
        color="#ffffff"
        anchorX="center"
        anchorY="middle"
        font="https://fonts.gstatic.com/s/rajdhani/v15/LDI2apCSOBg7SHTQkAwBqMcVabBF.woff2"
      >
        MAKE THE CONNECTION
      </Text>
      <Text
        position={[0, 3.9, 0]}
        fontSize={0.15}
        color="#6b7280"
        anchorX="center"
        anchorY="middle"
        font="https://fonts.gstatic.com/s/rajdhani/v15/LDI2apCSOBg7SHTQkAwBqMcVabBF.woff2"
      >
        Click the Master Ball
      </Text>

      <MasterBall />
    </group>
  );
}
