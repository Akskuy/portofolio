import { useRef, useState } from "react";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { useStore } from "@/store/useStore";
import { educationBuildings } from "@/data/resume";
import type { DetailContent } from "@/store/useStore";
import * as THREE from "three";

const buildingPositions: [number, number, number][] = [
  [0, 0, -6],
  [-5, 0, 0],
  [5, 0, 0],
  [0, 0, 6],
];

function CampusFountain() {
  const particlesRef = useRef<THREE.InstancedMesh>(null);
  const dummy = new THREE.Object3D();
  const particles = useRef(
    Array.from({ length: 30 }, () => ({
      x: (Math.random() - 0.5) * 1.5,
      y: Math.random() * 2,
      z: (Math.random() - 0.5) * 1.5,
      speed: 0.01 + Math.random() * 0.02,
      offset: Math.random() * Math.PI * 2,
    }))
  );

  useFrame((state) => {
    if (!particlesRef.current) return;
    particles.current.forEach((p, i) => {
      p.y += p.speed;
      p.x += Math.sin(state.clock.elapsedTime * 2 + p.offset) * 0.002;
      if (p.y > 2) {
        p.y = 0;
        p.x = (Math.random() - 0.5) * 1.5;
        p.z = (Math.random() - 0.5) * 1.5;
      }
      dummy.position.set(p.x, p.y, p.z);
      dummy.scale.setScalar(0.03 + p.y * 0.02);
      dummy.updateMatrix();
      particlesRef.current!.setMatrixAt(i, dummy.matrix);
    });
    particlesRef.current.instanceMatrix.needsUpdate = true;
  });

  return (
    <group position={[0, 0, 0]}>
      {/* Pool */}
      <mesh position={[0, 0.01, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <circleGeometry args={[2, 32]} />
        <meshStandardMaterial
          color="#0a1629"
          metalness={0.8}
          roughness={0.2}
          transparent
          opacity={0.8}
        />
      </mesh>
      {/* Pool edge glow */}
      <mesh position={[0, 0.02, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[1.95, 2, 32]} />
        <meshBasicMaterial color="#00f0ff" transparent opacity={0.3} />
      </mesh>
      {/* Water particles */}
      <instancedMesh ref={particlesRef} args={[undefined, undefined, 30]}>
        <sphereGeometry args={[1, 4, 4]} />
        <meshBasicMaterial color="#00f0ff" transparent opacity={0.6} />
      </instancedMesh>
      {/* Center spout */}
      <mesh position={[0, 0.5, 0]}>
        <cylinderGeometry args={[0.05, 0.1, 1, 8]} />
        <meshBasicMaterial color="#00f0ff" transparent opacity={0.3} />
      </mesh>
    </group>
  );
}

function Building({
  building,
  position,
  index,
}: {
  building: (typeof educationBuildings)[0];
  position: [number, number, number];
  index: number;
}) {
  const [hovered, setHovered] = useState(false);
  const meshRef = useRef<THREE.Mesh>(null);
  const { selectObject } = useStore();

  const handleClick = () => {
    const items: { label: string; value: string }[] = [];
    const meta: Record<string, string> = {};

    if (building.content.degree) {
      items.push({ label: "Degree", value: building.content.degree });
    }
    if (building.content.period) {
      items.push({ label: "Period", value: building.content.period });
    }
    if (building.content.location) {
      meta.Location = building.content.location;
    }
    if (building.content.status) {
      items.push({ label: "Status", value: building.content.status });
    }
    if (building.content.focus) {
      items.push({ label: "Focus", value: building.content.focus });
    }
    if (building.content.description) {
      items.push({ label: "Description", value: building.content.description });
    }
    if (building.content.activities) {
      building.content.activities.forEach((a) => {
        items.push({ label: "Activity", value: a });
      });
    }
    if (building.content.areas) {
      building.content.areas.forEach((a) => {
        items.push({ label: a.title, value: a.detail });
      });
    }
    if (building.content.modules) {
      items.push({ label: "Modules", value: building.content.modules.join(", ") });
    }

    const content: DetailContent = {
      type: "education",
      id: building.id,
      title: building.title,
      items,
      tags: building.content.skills || building.content.topics || [],
      meta: Object.keys(meta).length > 0 ? meta : undefined,
    };
    selectObject(building.id, content);
  };

  const heights = [3, 2.5, 2.5, 2];
  const widths = [4, 3, 3, 3.5];
  const height = heights[index];
  const width = widths[index];

  return (
    <group position={position}>
      {/* Building body */}
      <mesh
        ref={meshRef}
        position={[0, height / 2, 0]}
        onClick={handleClick}
        onPointerOver={() => {
          setHovered(true);
          document.body.style.cursor = "pointer";
        }}
        onPointerOut={() => {
          setHovered(false);
          document.body.style.cursor = "default";
        }}
      >
        <boxGeometry args={[width, height, 2.5]} />
        <meshStandardMaterial
          color="#0f1629"
          metalness={0.4}
          roughness={0.5}
          emissive={building.color}
          emissiveIntensity={hovered ? 0.15 : 0.03}
        />
      </mesh>
      {/* Building glow outline */}
      <mesh position={[0, height / 2, 0]}>
        <boxGeometry args={[width + 0.05, height + 0.05, 2.55]} />
        <meshBasicMaterial
          color={building.color}
          transparent
          opacity={hovered ? 0.3 : 0.05}
          wireframe
        />
      </mesh>
      {/* Windows */}
      {Array.from({ length: 3 }).map((_, row) =>
        Array.from({ length: 2 }).map((_, col) => (
          <mesh
            key={`${row}-${col}`}
            position={[
              (col - 0.5) * (width * 0.4),
              height * 0.3 + row * (height * 0.25),
              1.26,
            ]}
          >
            <planeGeometry args={[width * 0.2, height * 0.12]} />
            <meshBasicMaterial
              color={building.color}
              transparent
              opacity={0.3}
            />
          </mesh>
        ))
      )}
      {/* Roof */}
      <mesh position={[0, height + 0.25, 0]}>
        <boxGeometry args={[width + 0.2, 0.3, 2.7]} />
        <meshStandardMaterial color="#1a1a2e" metalness={0.5} roughness={0.3} />
      </mesh>
      {/* Entrance glow */}
      <mesh position={[0, 0.1, 1.26]}>
        <planeGeometry args={[1, 0.8]} />
        <meshBasicMaterial
          color={building.color}
          transparent
          opacity={hovered ? 0.6 : 0.2}
        />
      </mesh>
      {/* Label */}
      <Text
        position={[0, height + 0.8, 0]}
        fontSize={0.2}
        color={hovered ? "#ffffff" : building.color}
        anchorX="center"
        anchorY="middle"
        font="https://fonts.gstatic.com/s/rajdhani/v15/LDI2apCSOBg7SHTQkAwBqMcVabBF.woff2"
      >
        {building.title}
      </Text>
    </group>
  );
}

export default function EducationSection() {
  return (
    <group>
      {/* Campus lighting */}
      <pointLight position={[0, 8, 0]} intensity={0.6} color="#ffaa44" />
      <pointLight position={[-5, 5, 0]} intensity={0.4} color="#00f0ff" />
      <pointLight position={[5, 5, 0]} intensity={0.4} color="#9b59b6" />
      <ambientLight intensity={0.15} color="#4a9eff" />

      {/* Sky gradient simulation */}
      <fog attach="fog" args={["#1a1040", 20, 40]} />

      {/* Ground */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]}>
        <planeGeometry args={[40, 40]} />
        <meshStandardMaterial
          color="#0a0a12"
          metalness={0.2}
          roughness={0.8}
        />
      </mesh>
      {/* Grid on ground */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.01, 0]}>
        <planeGeometry args={[40, 40]} />
        <meshBasicMaterial
          color="#00f0ff"
          transparent
          opacity={0.03}
          wireframe
        />
      </mesh>

      {/* Title */}
      <Text
        position={[-6, 6, 0]}
        fontSize={0.4}
        color="#ffffff"
        anchorX="left"
        anchorY="middle"
        font="https://fonts.gstatic.com/s/rajdhani/v15/LDI2apCSOBg7SHTQkAwBqMcVabBF.woff2"
      >
        EDUCATION REGION
      </Text>
      <Text
        position={[-6, 5.4, 0]}
        fontSize={0.2}
        color="#6b7280"
        anchorX="left"
        anchorY="middle"
      >
        Explore the campus of learning
      </Text>

      {/* Campus Fountain */}
      <CampusFountain />

      {/* Buildings */}
      {educationBuildings.map((building, i) => (
        <Building
          key={building.id}
          building={building}
          position={buildingPositions[i]}
          index={i}
        />
      ))}

      {/* Street lamps */}
      {[
        [-3, 0, 3],
        [3, 0, 3],
        [-3, 0, -3],
        [3, 0, -3],
      ].map((pos, i) => (
        <group key={i} position={pos as [number, number, number]}>
          <mesh position={[0, 1.5, 0]}>
            <cylinderGeometry args={[0.05, 0.08, 3, 8]} />
            <meshStandardMaterial color="#333" />
          </mesh>
          <pointLight position={[0, 3, 0]} intensity={0.5} color="#ffaa44" distance={5} />
          <mesh position={[0, 3, 0]}>
            <sphereGeometry args={[0.15, 8, 8]} />
            <meshBasicMaterial color="#ffaa44" transparent opacity={0.8} />
          </mesh>
        </group>
      ))}
    </group>
  );
}
