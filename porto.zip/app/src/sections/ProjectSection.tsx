import { useRef, useState, useMemo } from "react";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { useStore } from "@/store/useStore";
import { projects } from "@/data/resume";
import type { DetailContent } from "@/store/useStore";
import * as THREE from "three";

const portalPositions: [number, number, number][] = [
  [0, 0, 0],
  [-4, 0.5, -1],
  [4, 0.5, -1],
  [-6, -0.5, -3],
  [6, -0.5, -3],
];

const portalScales = [1.2, 0.9, 0.9, 0.75, 0.75];

function PortalSwirl({ color, count = 400 }: { color: string; count?: number }) {
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const dummy = useMemo(() => new THREE.Object3D(), []);

  const particles = useMemo(
    () =>
      Array.from({ length: count }, (_, i) => ({
        angle: (i / count) * Math.PI * 2,
        radius: 0.3 + Math.random() * 1.5,
        speed: 0.5 + Math.random() * 1.5,
        yOffset: (Math.random() - 0.5) * 0.2,
        size: 0.01 + Math.random() * 0.02,
      })),
    [count]
  );

  useFrame((state) => {
    if (!meshRef.current) return;
    const time = state.clock.elapsedTime;
    particles.forEach((p, i) => {
      const t = time * p.speed;
      const x = Math.cos(p.angle + t) * p.radius;
      const z = Math.sin(p.angle + t) * p.radius;
      const y = p.yOffset + Math.sin(t * 2 + p.angle) * 0.05;
      dummy.position.set(x, y, z);
      dummy.scale.setScalar(p.size * (1 + Math.sin(t * 3 + i) * 0.3));
      dummy.updateMatrix();
      meshRef.current!.setMatrixAt(i, dummy.matrix);
    });
    meshRef.current.instanceMatrix.needsUpdate = true;
  });

  return (
    <instancedMesh ref={meshRef} args={[undefined, undefined, count]}>
      <sphereGeometry args={[1, 4, 4]} />
      <meshBasicMaterial color={color} transparent opacity={0.7} blending={THREE.AdditiveBlending} />
    </instancedMesh>
  );
}

function PortalRing({ color, intensity }: { color: string; intensity: number }) {
  const ringRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (ringRef.current) {
      ringRef.current.rotation.z = -state.clock.elapsedTime * 0.5;
      const mat = ringRef.current.material as THREE.MeshBasicMaterial;
      mat.opacity = 0.4 + Math.sin(state.clock.elapsedTime * 2) * 0.2;
    }
  });

  return (
    <mesh ref={ringRef}>
      <torusGeometry args={[1.8, 0.05, 8, 64]} />
      <meshBasicMaterial
        color={color}
        transparent
        opacity={intensity * 0.5}
        blending={THREE.AdditiveBlending}
      />
    </mesh>
  );
}

function Portal({
  project,
  position,
  scale,
  index,
}: {
  project: (typeof projects)[0];
  position: [number, number, number];
  scale: number;
  index: number;
}) {
  const [hovered, setHovered] = useState(false);
  const groupRef = useRef<THREE.Group>(null);
  const { selectObject } = useStore();

  const handleClick = () => {
    const content: DetailContent = {
      type: "project",
      id: project.id,
      title: project.title,
      description: project.description,
      items: [
        { label: "Challenges", value: project.challenges },
        { label: "Solutions", value: project.solutions },
        { label: "Outcomes", value: project.outcomes },
      ],
      tags: project.techStack,
    };
    selectObject(project.id, content);
  };

  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.position.y = position[1] + Math.sin(state.clock.elapsedTime * 0.8 + index * 2) * 0.1;
    }
  });

  return (
    <group ref={groupRef} position={position}>
      <group
        scale={scale}
        onClick={handleClick}
        onPointerOver={() => {
          setHovered(true);
          document.body.style.cursor = "pointer";
        }}
        onPointerOut={() => {
          setHovered(false);
          document.body.style.cursor = "default";
        }}
      >
        {/* Portal background disc */}
        <mesh>
          <circleGeometry args={[1.8, 32]} />
          <meshBasicMaterial
            color={project.color}
            transparent
            opacity={0.05}
            side={THREE.DoubleSide}
          />
        </mesh>
        {/* Swirling particles */}
        <PortalSwirl color={project.color} count={hovered ? 500 : 350} />
        {/* Energy rings */}
        <PortalRing color={project.color} intensity={hovered ? 1.5 : 1} />
        <mesh>
          <torusGeometry args={[1.5, 0.03, 8, 64]} />
          <meshBasicMaterial
            color={project.color}
            transparent
            opacity={hovered ? 0.8 : 0.4}
            blending={THREE.AdditiveBlending}
          />
        </mesh>
        {/* Center glow */}
        <mesh>
          <sphereGeometry args={[0.3, 8, 8]} />
          <meshBasicMaterial
            color={project.color}
            transparent
            opacity={0.3}
            blending={THREE.AdditiveBlending}
          />
        </mesh>
      </group>
      {/* Label */}
      <Text
        position={[0, -2.2 * scale, 0]}
        fontSize={0.18}
        color={hovered ? "#ffffff" : project.color}
        anchorX="center"
        anchorY="middle"
        font="https://fonts.gstatic.com/s/rajdhani/v15/LDI2apCSOBg7SHTQkAwBqMcVabBF.woff2"
      >
        {project.title.toUpperCase()}
      </Text>
    </group>
  );
}

export default function ProjectSection() {
  return (
    <group>
      <pointLight position={[0, 5, 5]} intensity={0.5} color="#ffffff" />
      <ambientLight intensity={0.05} />

      {/* Title */}
      <Text
        position={[-6, 4, 0]}
        fontSize={0.4}
        color="#ffffff"
        anchorX="left"
        anchorY="middle"
        font="https://fonts.gstatic.com/s/rajdhani/v15/LDI2apCSOBg7SHTQkAwBqMcVabBF.woff2"
      >
        PROJECT MULTIVERSE
      </Text>
      <Text
        position={[-6, 3.4, 0]}
        fontSize={0.2}
        color="#6b7280"
        anchorX="left"
        anchorY="middle"
      >
        Enter a project dimension
      </Text>

      {projects.map((project, i) => (
        <Portal
          key={project.id}
          project={project}
          position={portalPositions[i]}
          scale={portalScales[i]}
          index={i}
        />
      ))}
    </group>
  );
}
