import { useRef, useState, useMemo } from "react";
import { useFrame } from "@react-three/fiber";
import { Float, Html, Text } from "@react-three/drei";
import { RigidBody, CuboidCollider } from "@react-three/rapier";
import { useStore } from "@/store/useStore";
import { profile } from "@/data/resume";
import * as THREE from "three";

function FloatingParticles() {
  const count = 200;
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const particles = useMemo(() => {
    const temp = [];
    for (let i = 0; i < count; i++) {
      temp.push({
        position: new THREE.Vector3(
          (Math.random() - 0.5) * 20,
          (Math.random() - 0.5) * 20,
          (Math.random() - 0.5) * 10
        ),
        speed: 0.02 + Math.random() * 0.03,
        wobble: Math.random() * Math.PI * 2,
        color: ["#00f0ff", "#00d4aa", "#4a9eff"][Math.floor(Math.random() * 3)],
      });
    }
    return temp;
  }, []);

  const dummy = useMemo(() => new THREE.Object3D(), []);

  useFrame((state) => {
    if (!meshRef.current) return;
    particles.forEach((p, i) => {
      p.position.y += p.speed;
      p.position.x += Math.sin(state.clock.elapsedTime + p.wobble) * 0.002;
      if (p.position.y > 10) p.position.y = -10;
      dummy.position.copy(p.position);
      dummy.scale.setScalar(0.02 + Math.sin(state.clock.elapsedTime * 2 + i) * 0.01);
      dummy.updateMatrix();
      meshRef.current!.setMatrixAt(i, dummy.matrix);
    });
    meshRef.current.instanceMatrix.needsUpdate = true;
  });

  return (
    <instancedMesh ref={meshRef} args={[undefined, undefined, count]}>
      <sphereGeometry args={[1, 4, 4]} />
      <meshBasicMaterial color="#00f0ff" transparent opacity={0.6} />
    </instancedMesh>
  );
}

function LicenseCard() {
  const [flipped, setFlipped] = useState(false);
  const cardRef = useRef<THREE.Group>(null);

  const handleFlip = () => {
    setFlipped(!flipped);
  };

  useFrame(() => {
    if (cardRef.current) {
      const targetRotation = flipped ? Math.PI : 0;
      cardRef.current.rotation.y += (targetRotation - cardRef.current.rotation.y) * 0.05;
    }
  });

  return (
    <Float speed={1.5} rotationIntensity={0.1} floatIntensity={0.3}>
      <group
        ref={cardRef}
        onClick={handleFlip}
        onPointerOver={() => (document.body.style.cursor = "pointer")}
        onPointerOut={() => (document.body.style.cursor = "default")}
      >
        <RigidBody colliders="cuboid" mass={0.1} gravityScale={0.3}>
          <CuboidCollider args={[1.75, 2.5, 0.04]} />
          {/* Card Front */}
          <mesh position={[0, 0, 0.04]}>
            <planeGeometry args={[3.5, 5]} />
            <meshStandardMaterial
              color="#0f1629"
              metalness={0.8}
              roughness={0.2}
              emissive="#00f0ff"
              emissiveIntensity={0.05}
            />
          </mesh>
          {/* Card Border Glow */}
          <mesh position={[0, 0, 0.045]}>
            <planeGeometry args={[3.48, 4.98]} />
            <meshBasicMaterial color="#00f0ff" transparent opacity={0.3} />
          </mesh>
          {/* Front Content - HTML Overlay */}
          <Html
            position={[0, 0, 0.05]}
            transform
            occlude
            style={{
              width: "350px",
              height: "500px",
              pointerEvents: "none",
              display: flipped ? "none" : "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <div className="w-full h-full flex flex-col items-center justify-between py-8 px-6 relative overflow-hidden">
              {/* Holographic shine */}
              <div
                className="absolute inset-0 pointer-events-none"
                style={{
                  background:
                    "linear-gradient(90deg, transparent 40%, rgba(0,240,255,0.1) 50%, transparent 60%)",
                  animation: "holoShine 4s linear infinite",
                }}
              />
              <div
                className="text-xs tracking-[0.2em] text-cyan-400"
                style={{ fontFamily: "Rajdhani" }}
              >
                TRAINER LICENSE
              </div>
              {/* Shield Badge */}
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-cyan-400/20 to-blue-500/20 border-2 border-cyan-400/50 flex items-center justify-center">
                <svg viewBox="0 0 24 24" className="w-8 h-8 text-cyan-400" fill="currentColor">
                  <path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z" />
                </svg>
              </div>
              {/* Photo Placeholder */}
              <div className="w-28 h-36 rounded-xl border-2 border-cyan-400/50 bg-gradient-to-b from-cyan-400/10 to-transparent flex items-center justify-center overflow-hidden">
                <div className="text-4xl">👤</div>
              </div>
              {/* Name */}
              <div className="text-center">
                <h1
                  className="text-lg font-bold text-white tracking-wide"
                  style={{ fontFamily: "Rajdhani" }}
                >
                  {profile.name}
                </h1>
                <div className="w-32 h-px bg-white/20 mx-auto my-3" />
                <div className="flex flex-col gap-2 items-center">
                  <span className="holo-badge text-[10px] py-1 px-3">
                    {profile.role}
                  </span>
                  <span className="holo-badge text-[10px] py-1 px-3" style={{ color: "#4a9eff", borderColor: "#4a9eff", background: "rgba(74,158,255,0.15)" }}>
                    {profile.title}
                  </span>
                  <span className="gold-badge text-[10px] py-1 px-3">
                    {profile.tagline}
                  </span>
                </div>
              </div>
            </div>
          </Html>

          {/* Card Back */}
          <mesh position={[0, 0, -0.04]} rotation={[0, Math.PI, 0]}>
            <planeGeometry args={[3.5, 5]} />
            <meshStandardMaterial
              color="#0f1629"
              metalness={0.8}
              roughness={0.2}
              emissive="#4a9eff"
              emissiveIntensity={0.03}
            />
          </mesh>
          {/* Back Content */}
          <Html
            position={[0, 0, -0.05]}
            transform
            occlude
            rotation={[0, Math.PI, 0]}
            style={{
              width: "350px",
              height: "500px",
              pointerEvents: "none",
              display: flipped ? "flex" : "none",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <div className="w-full h-full flex flex-col items-center justify-center py-8 px-6">
              <h2
                className="text-xl font-semibold text-white mb-8"
                style={{ fontFamily: "Rajdhani", letterSpacing: "0.05em" }}
              >
                TRAINER PROFILE
              </h2>
              <div className="space-y-4 w-full">
                {[
                  { icon: "📧", text: profile.email, href: `mailto:${profile.email}` },
                  { icon: "💼", text: profile.linkedin, href: `https://${profile.linkedin}` },
                  { icon: "⚡", text: profile.github, href: `https://${profile.github}` },
                  { icon: "📱", text: profile.phone, href: `tel:${profile.phone}` },
                ].map((item) => (
                  <a
                    key={item.text}
                    href={item.href}
                    target={item.href.startsWith("http") ? "_blank" : undefined}
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 p-3 rounded-lg hover:bg-white/5 transition-colors group"
                  >
                    <span className="text-cyan-400 text-lg">{item.icon}</span>
                    <span className="text-gray-400 text-sm group-hover:text-white transition-colors truncate">
                      {item.text}
                    </span>
                  </a>
                ))}
              </div>
            </div>
          </Html>
        </RigidBody>
      </group>
    </Float>
  );
}

function LanyardRope() {
  return (
    <group position={[0, 5, 0]}>
      {/* Simple visual rope */}
      <mesh position={[0, -2.5, 0]}>
        <cylinderGeometry args={[0.03, 0.03, 5, 8]} />
        <meshStandardMaterial color="#333" roughness={0.8} />
      </mesh>
      {/* Anchor point */}
      <mesh position={[0, 0, 0]}>
        <sphereGeometry args={[0.1, 8, 8]} />
        <meshStandardMaterial color="#555" metalness={0.5} />
      </mesh>
    </group>
  );
}

export default function HeroSection() {
  const { setLoading } = useStore();

  // Hide loading after a short delay
  setTimeout(() => setLoading(false), 1000);

  return (
    <group>
      <pointLight position={[-3, 3, 2]} intensity={0.8} color="#00f0ff" />
      <pointLight position={[3, 2, 3]} intensity={0.6} color="#4a9eff" />
      
      <FloatingParticles />
      <LanyardRope />
      <LicenseCard />
      
      {/* Subtitle hint */}
      <Text
        position={[0, -4.5, 0]}
        fontSize={0.25}
        color="#6b7280"
        anchorX="center"
        anchorY="middle"
        font="https://fonts.gstatic.com/s/rajdhani/v15/LDI2apCSOBg7SHTQkAwBqMcVabBF.woff2"
      >
        DRAG · ROTATE · FLIP · THROW
      </Text>

      {/* Floor collider */}
      <CuboidCollider position={[0, -5, 0]} args={[20, 0.1, 20]} />
    </group>
  );
}
