import { useRef, useState } from "react";
import { useFrame } from "@react-three/fiber";
import { Float, Text } from "@react-three/drei";
import { useStore } from "@/store/useStore";
import { experiences } from "@/data/resume";
import type { DetailContent } from "@/store/useStore";
import * as THREE from "three";

const platformPositions: [number, number, number][] = [
  [-6, 0, -4],
  [6, 0, -4],
  [-4, 0, 6],
  [4, 0, 6],
  [0, 0, -8],
];

function ExperiencePlatform({
  exp,
  position,
  index,
}: {
  exp: (typeof experiences)[0];
  position: [number, number, number];
  index: number;
}) {
  const [hovered, setHovered] = useState(false);
  const [entered, setEntered] = useState(false);
  const groupRef = useRef<THREE.Group>(null);
  const { selectObject, setBackButtonVisible } = useStore();

  const handleClick = () => {
    if (!entered) {
      setEntered(true);
      setBackButtonVisible(true);
    }
  };

  const handleObjectClick = (obj: { name: string; description: string }) => {
    const content: DetailContent = {
      type: "experience",
      id: `${exp.id}-${obj.name}`,
      title: obj.name,
      subtitle: exp.title,
      description: obj.description,
      meta: {
        Period: exp.period,
        Location: exp.location,
      },
    };
    selectObject(`${exp.id}-${obj.name}`, content);
  };

  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.position.y =
        position[1] + Math.sin(state.clock.elapsedTime * 0.8 + index) * 0.1;
    }
  });

  return (
    <group ref={groupRef} position={position}>
      {/* Platform Base */}
      <mesh
        onClick={handleClick}
        onPointerOver={() => {
          setHovered(true);
          document.body.style.cursor = "pointer";
        }}
        onPointerOut={() => {
          setHovered(false);
          document.body.style.cursor = "default";
        }}
      >
        <cylinderGeometry args={[2, 2.2, 0.3, 6]} />
        <meshStandardMaterial
          color="#0f1629"
          metalness={0.5}
          roughness={0.4}
          emissive={exp.color}
          emissiveIntensity={hovered ? 0.2 : 0.05}
        />
      </mesh>
      {/* Platform Glow Ring */}
      <mesh position={[0, 0.16, 0]}>
        <cylinderGeometry args={[2.05, 2.05, 0.02, 6]} />
        <meshBasicMaterial
          color={exp.color}
          transparent
          opacity={hovered ? 0.6 : 0.2}
        />
      </mesh>
      {/* Platform Name */}
      <Text
        position={[0, 3, 0]}
        fontSize={0.25}
        color={hovered ? "#ffffff" : exp.color}
        anchorX="center"
        anchorY="middle"
        font="https://fonts.gstatic.com/s/rajdhani/v15/LDI2apCSOBg7SHTQkAwBqMcVabBF.woff2"
      >
        {exp.title}
      </Text>
      <Text
        position={[0, 2.6, 0]}
        fontSize={0.15}
        color="#6b7280"
        anchorX="center"
        anchorY="middle"
      >
        {exp.period}
      </Text>

      {/* Interactive Objects (only visible when entered) */}
      {entered &&
        exp.objects.map((obj, i) => {
          const angle = (i / exp.objects.length) * Math.PI * 2;
          const radius = 1.2;
          const x = Math.cos(angle) * radius;
          const z = Math.sin(angle) * radius;
          return (
            <Float key={obj.name} speed={2} floatIntensity={0.3}>
              <group
                position={[x, 1.2, z]}
                onClick={(e) => {
                  e.stopPropagation();
                  handleObjectClick(obj);
                }}
                onPointerOver={() => (document.body.style.cursor = "pointer")}
                onPointerOut={() => (document.body.style.cursor = "default")}
              >
                {/* Object shape */}
                <mesh>
                  <sphereGeometry args={[0.3, 8, 8]} />
                  <meshStandardMaterial
                    color={exp.color}
                    emissive={exp.color}
                    emissiveIntensity={0.4}
                    transparent
                    opacity={0.8}
                  />
                </mesh>
                {/* Object label */}
                <Text
                  position={[0, 0.5, 0]}
                  fontSize={0.12}
                  color="#ffffff"
                  anchorX="center"
                  anchorY="middle"
                  font="https://fonts.gstatic.com/s/rajdhani/v15/LDI2apCSOBg7SHTQkAwBqMcVabBF.woff2"
                >
                  {obj.name}
                </Text>
              </group>
            </Float>
          );
        })}
    </group>
  );
}

function HubPlatform() {
  return (
    <group position={[0, -0.5, 0]}>
      <mesh>
        <cylinderGeometry args={[3, 3, 0.2, 32]} />
        <meshStandardMaterial
          color="#0f1629"
          metalness={0.3}
          roughness={0.6}
          transparent
          opacity={0.8}
        />
      </mesh>
      {/* Grid lines on hub */}
      <mesh position={[0, 0.11, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[6, 6]} />
        <meshBasicMaterial
          color="#00f0ff"
          transparent
          opacity={0.05}
          wireframe
        />
      </mesh>
      {/* Center pillar */}
      <mesh position={[0, 1.5, 0]}>
        <cylinderGeometry args={[0.1, 0.1, 3, 8]} />
        <meshBasicMaterial color="#00f0ff" transparent opacity={0.3} />
      </mesh>
      {/* Rotating ring */}
      <Ring rotation={[Math.PI / 2, 0, 0]} />
    </group>
  );
}

function Ring({ rotation }: { rotation: [number, number, number] }) {
  const ringRef = useRef<THREE.Mesh>(null);
  useFrame((state) => {
    if (ringRef.current) {
      ringRef.current.rotation.z = state.clock.elapsedTime * 0.5;
    }
  });
  return (
    <mesh ref={ringRef} position={[0, 3, 0]} rotation={rotation}>
      <torusGeometry args={[0.4, 0.02, 8, 32]} />
      <meshBasicMaterial color="#00f0ff" transparent opacity={0.6} />
    </mesh>
  );
}

export default function ExperienceSection() {
  return (
    <group>
      <pointLight position={[0, 10, 0]} intensity={0.8} color="#ffffff" />
      <ambientLight intensity={0.2} color="#4a9eff" />

      {/* Hub */}
      <HubPlatform />

      {/* Title */}
      <Text
        position={[-5, 5, 0]}
        fontSize={0.4}
        color="#ffffff"
        anchorX="left"
        anchorY="middle"
        font="https://fonts.gstatic.com/s/rajdhani/v15/LDI2apCSOBg7SHTQkAwBqMcVabBF.woff2"
      >
        EXPERIENCE ARENA
      </Text>

      {/* Platforms */}
      {experiences.map((exp, i) => (
        <ExperiencePlatform
          key={exp.id}
          exp={exp}
          position={platformPositions[i]}
          index={i}
        />
      ))}

      {/* Connecting paths */}
      {platformPositions.map((pos, i) => (
        <mesh key={i} position={[(pos[0]) / 2, -0.4, pos[2] / 2]}>
          <boxGeometry args={[0.05, 0.02, Math.sqrt(pos[0] ** 2 + pos[2] ** 2)]} />
          <meshBasicMaterial color="#00f0ff" transparent opacity={0.1} />
        </mesh>
      ))}
    </group>
  );
}
