import { motion, AnimatePresence } from "framer-motion";
import { X } from "lucide-react";
import { useStore } from "@/store/useStore";

export default function DataDetailPanel() {
  const { detailPanelOpen, detailContent, selectObject } = useStore();

  if (!detailContent) return null;

  return (
    <AnimatePresence>
      {detailPanelOpen && (
        <motion.div
          initial={{ x: "100%", opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          exit={{ x: "100%", opacity: 0 }}
          transition={{ duration: 0.4, ease: "easeOut" }}
          className="fixed top-0 right-0 z-50 h-full w-[420px] max-w-[90vw] overflow-y-auto"
          style={{
            background: "rgba(15, 22, 41, 0.9)",
            backdropFilter: "blur(20px)",
            borderLeft: "1px solid rgba(0, 240, 255, 0.2)",
          }}
        >
          <button
            onClick={() => selectObject(null, null)}
            className="absolute top-4 right-4 z-10 w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5 text-white" />
          </button>

          <div className="p-8 pt-16">
            <h2
              className="text-2xl font-bold mb-2"
              style={{ fontFamily: "Rajdhani", color: "#00f0ff" }}
            >
              {detailContent.title}
            </h2>
            {detailContent.subtitle && (
              <p className="text-gray-400 mb-6">{detailContent.subtitle}</p>
            )}

            {detailContent.description && (
              <p className="text-gray-300 mb-6 leading-relaxed">
                {detailContent.description}
              </p>
            )}

            {detailContent.items && detailContent.items.length > 0 && (
              <div className="space-y-4 mb-6">
                {detailContent.items.map((item, i) => (
                  <div
                    key={i}
                    className="glass-panel-light"
                  >
                    <h3
                      className="text-sm font-semibold mb-1"
                      style={{
                        fontFamily: "Rajdhani",
                        color: "#00f0ff",
                        letterSpacing: "0.05em",
                      }}
                    >
                      {item.label}
                    </h3>
                    <p className="text-gray-300 text-sm">{item.value}</p>
                  </div>
                ))}
              </div>
            )}

            {detailContent.meta &&
              Object.entries(detailContent.meta).map(([key, value]) => (
                <div key={key} className="mb-3">
                  <span
                    className="text-xs uppercase tracking-wider text-gray-500"
                    style={{ fontFamily: "Rajdhani" }}
                  >
                    {key}
                  </span>
                  <p className="text-gray-300">{value}</p>
                </div>
              ))}

            {detailContent.tags && detailContent.tags.length > 0 && (
              <div className="mt-6">
                <h3
                  className="text-xs uppercase tracking-wider text-gray-500 mb-3"
                  style={{ fontFamily: "Rajdhani" }}
                >
                  Skills
                </h3>
                <div className="flex flex-wrap gap-2">
                  {detailContent.tags.map((tag) => (
                    <span key={tag} className="holo-badge text-xs">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
