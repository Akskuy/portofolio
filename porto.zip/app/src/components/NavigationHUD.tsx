import { useStore, sectionNames } from "@/store/useStore";

export default function NavigationHUD() {
  const { activeSection, isTransitioning, setActiveSection } = useStore();

  return (
    <nav className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 p-2 rounded-full bg-black/40 backdrop-blur-xl border border-white/10">
      {sectionNames.map((name, index) => (
        <button
          key={name}
          onClick={() => setActiveSection(index)}
          disabled={isTransitioning}
          className={`nav-pill ${
            activeSection === index ? "nav-pill-active" : "nav-pill-inactive"
          }`}
        >
          {name}
        </button>
      ))}
    </nav>
  );
}
