import { useStore } from "@/store/useStore";
import { Suspense, lazy } from "react";
import { Stars } from "@react-three/drei";

const HeroSection = lazy(() => import("@/sections/HeroSection"));
const EvolutionSection = lazy(() => import("@/sections/EvolutionSection"));
const ExperienceSection = lazy(() => import("@/sections/ExperienceSection"));
const AchievementSection = lazy(() => import("@/sections/AchievementSection"));
const SkillSection = lazy(() => import("@/sections/SkillSection"));
const ProjectSection = lazy(() => import("@/sections/ProjectSection"));
const EducationSection = lazy(() => import("@/sections/EducationSection"));
const ContactSection = lazy(() => import("@/sections/ContactSection"));

const sections = [
  HeroSection,
  EvolutionSection,
  ExperienceSection,
  AchievementSection,
  SkillSection,
  ProjectSection,
  EducationSection,
  ContactSection,
];

export default function SectionRenderer() {
  const { activeSection } = useStore();
  const Section = sections[activeSection];

  return (
    <Suspense fallback={null}>
      <Stars radius={100} depth={50} count={2000} factor={4} saturation={0} fade speed={1} />
      <fog attach="fog" args={["#0a0a0f", 15, 40]} />
      <ambientLight intensity={0.3} />
      <Section />
    </Suspense>
  );
}
