import { motion, AnimatePresence } from "framer-motion";
import { useStore } from "@/store/useStore";

export default function LoadingScreen() {
  const { loading } = useStore();

  return (
    <AnimatePresence>
      {loading && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.8 }}
          className="fixed inset-0 z-[100] flex flex-col items-center justify-center"
          style={{ background: "#0a0a0f" }}
        >
          <div className="relative w-20 h-20 mb-8">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
              className="w-full h-full rounded-full"
              style={{
                background: "conic-gradient(from 0deg, #00f0ff, #4a9eff, #00d4aa, #00f0ff)",
                mask: "radial-gradient(circle, transparent 55%, black 56%)",
                WebkitMask: "radial-gradient(circle, transparent 55%, black 56%)",
              }}
            />
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-12 h-12 rounded-full bg-gradient-to-b from-[#9b59b6] to-white relative overflow-hidden">
                <div className="absolute top-0 left-0 right-0 h-1/2 bg-[#9b59b6]" />
                <div className="absolute bottom-0 left-0 right-0 h-1/2 bg-white" />
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4 rounded-full bg-[#1a1a1a] border-2 border-white" />
                <div className="absolute top-1/2 left-0 right-0 h-[2px] bg-[#1a1a1a]" />
              </div>
            </div>
          </div>
          <motion.p
            animate={{ opacity: [0.4, 1, 0.4] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="text-lg tracking-widest"
            style={{ fontFamily: "Rajdhani", color: "#00f0ff" }}
          >
            Loading Universe...
          </motion.p>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
