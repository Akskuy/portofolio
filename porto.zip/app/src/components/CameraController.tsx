import { useRef, useEffect } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import { useStore } from "@/store/useStore";
import gsap from "gsap";
import { Vector3 } from "three";

export default function CameraController() {
  const { camera } = useThree();
  const { cameraTarget, cameraMode, isTransitioning } = useStore();
  const currentPos = useRef(new Vector3().copy(camera.position));
  const currentLook = useRef(new Vector3(0, 0, 0));
  const targetLook = useRef(new Vector3().copy(cameraTarget.lookAt));

  useEffect(() => {
    if (isTransitioning) {
      gsap.to(currentPos.current, {
        x: cameraTarget.position.x,
        y: cameraTarget.position.y,
        z: cameraTarget.position.z,
        duration: 1.5,
        ease: "power2.inOut",
      });
      gsap.to(targetLook.current, {
        x: cameraTarget.lookAt.x,
        y: cameraTarget.lookAt.y,
        z: cameraTarget.lookAt.z,
        duration: 1.5,
        ease: "power2.inOut",
      });
    }
  }, [cameraTarget, isTransitioning]);

  useFrame(() => {
    if (cameraMode === "cinematic" || isTransitioning) {
      camera.position.lerp(currentPos.current, 0.05);
      currentLook.current.lerp(targetLook.current, 0.05);
      camera.lookAt(currentLook.current);
    }
  });

  return null;
}
