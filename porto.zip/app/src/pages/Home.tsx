import { Suspense } from "react";
import { Canvas } from "@react-three/fiber";
import { OrbitControls, Preload } from "@react-three/drei";
import { Physics } from "@react-three/rapier";
import NavigationHUD from "@/components/NavigationHUD";
import DataDetailPanel from "@/components/DataDetailPanel";
import LoadingScreen from "@/components/LoadingScreen";
import BackButton from "@/components/BackButton";
import CameraController from "@/components/CameraController";
import SectionRenderer from "@/components/SectionRenderer";
import { useStore } from "@/store/useStore";

function Scene() {
  const { cameraMode } = useStore();

  return (
    <>
      <CameraController />
      <SectionRenderer />
      <OrbitControls
        enabled={cameraMode === "free"}
        enablePan={false}
        enableZoom={true}
        minDistance={3}
        maxDistance={30}
        dampingFactor={0.05}
        enableDamping
        rotateSpeed={0.5}
      />
      <Preload all />
    </>
  );
}

export default function Home() {
  return (
    <div className="w-screen h-screen relative overflow-hidden" style={{ background: "#0a0a0f" }}>
      {/* 3D Canvas */}
      <Canvas
        camera={{
          position: [0, 0, 8],
          fov: 60,
          near: 0.1,
          far: 200,
        }}
        dpr={[1, 2]}
        gl={{
          antialias: true,
          alpha: false,
          powerPreference: "high-performance",
        }}
        onCreated={() => {
          // Hide loading after canvas is ready
          setTimeout(() => {
            useStore.getState().setLoading(false);
          }, 1500);
        }}
      >
        <color attach="background" args={["#0a0a0f"]} />
        <Suspense fallback={null}>
          <Physics gravity={[0, -2, 0]}>
            <Scene />
          </Physics>
        </Suspense>
      </Canvas>

      {/* UI Overlays */}
      <LoadingScreen />
      <NavigationHUD />
      <DataDetailPanel />
      <BackButton />

      {/* Interactive hint at bottom */}
      <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-40 pointer-events-none">
        <p
          className="text-xs tracking-widest text-cyan-400/60 hint-pulse"
          style={{ fontFamily: "Rajdhani" }}
        >
          Click objects to explore
        </p>
      </div>
    </div>
  );
}
