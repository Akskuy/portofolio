# Tech Spec — Trainer Kiagus Arif Rahman 3D Career Universe

## Dependencies

### Core 3D & Physics
| Package | Version | Purpose |
|---------|---------|---------|
| `three` | ^0.170 | 3D engine — scenes, geometries, materials, lighting, custom shaders |
| `@react-three/fiber` | ^9 | React renderer for Three.js — declarative 3D scene graph |
| `@react-three/drei` | ^10 | R3F helpers — Html overlays, soft shadows, useTexture, Float, MeshDistortMaterial, Stars, OrbitControls |
| `@react-three/postprocessing` | ^3 | Screen-space effects — Bloom, ChromaticAberration, Vignette |
| `@react-three/rapier` | ^2 | Physics engine — rigid bodies, joints, collisions, grab/throw mechanics |

### Animation
| Package | Version | Purpose |
|---------|---------|---------|
| `gsap` | ^3 | Complex sequenced animations — entrance timelines, camera fly-throughs, staggered reveals |
| `framer-motion` | ^12 | UI layer animations — panel slide-ins, button transitions, form states |

### State Management
| Package | Version | Purpose |
|---------|---------|---------|
| `zustand` | ^5 | Lightweight global state — active section, selected object, camera target, UI panel visibility |

### UI & Styling
| Package | Version | Purpose |
|---------|---------|---------|
| `tailwindcss` | ^4 | Utility-first styling |
| `shadcn/ui` | latest | Base UI primitives (Button, Input, Textarea used in contact form) |
| `lucide-react` | ^0.460 | Icon set — GitHub, LinkedIn, Mail, Download, ArrowLeft, X, ChevronLeft, etc. |

### Utilities
| Package | Version | Purpose |
|---------|---------|---------|
| `clsx` | ^2 | Conditional class joining |
| `tailwind-merge` | ^3 | Tailwind class conflict resolution |

### Fonts (Google Fonts CDN — no npm install)
- **Rajdhani** (400, 500, 600, 700) — headings, hero text, UI labels
- **Inter** (400, 500, 600) — body text, descriptions, form inputs

### Full package.json dependencies
```json
{
  "dependencies": {
    "react": "^19",
    "react-dom": "^19",
    "three": "^0.170",
    "@react-three/fiber": "^9",
    "@react-three/drei": "^10",
    "@react-three/postprocessing": "^3",
    "@react-three/rapier": "^2",
    "gsap": "^3",
    "framer-motion": "^12",
    "zustand": "^5",
    "tailwindcss": "^4",
    "lucide-react": "^0.460",
    "clsx": "^2",
    "tailwind-merge": "^3",
    "class-variance-authority": "^0.7",
    "@radix-ui/react-slot": "^1"
  }
}
```

---

## Component Inventory

### Layout (shared across all sections)

| Component | Source | Reuse |
|-----------|--------|-------|
| `NavigationHUD` | Custom | All sections — 8 section pills, active state, camera transition triggers |
| `InteractiveHint` | Custom | All sections — context-aware floating labels ("Drag to move", "Click to enter") |
| `DataDetailPanel` | Custom | Sections 2, 4, 5, 6, 7 — right-slide panel for selected object details |
| `BackButton` | Custom | Sections 3, 6, 7 — circular return button for subsections |
| `LoadingScreen` | Custom | Once — full-screen Pokeball-inspired loader |

### Sections (one per major section, conditionally rendered)

| Component | Key Contents |
|-----------|-------------|
| `HeroSection` | LicenseCard, LanyardRope, floating particles |
| `EvolutionSection` | 8 EvolutionCards in scattered formation |
| `ExperienceSection` | HubPlatform + 5 ExperienceLocation platforms |
| `AchievementSection` | 3 Trophy items on pedestals with volumetric lights |
| `SkillSection` | Galaxy core, 5 SkillClusters, constellation lines, 27+ Star nodes |
| `ProjectSection` | 5 Portal vortexes |
| `EducationSection` | Campus plaza with 4 buildings + fountain |
| `ContactSection` | MasterBall with opening animation |

### Reusable 3D Components

| Component | Source | Used By |
|-----------|--------|---------|
| `GlassPanel` | Custom + drei `Html` | Detail panels, UI overlays in 3D space |
| `HolographicCard` | Custom shader material | LicenseCard, EvolutionCards |
| `HolographicShine` | Custom (animated uniform) | All cards — sweep gradient overlay |
| `FloatingParticles` | Custom (instanced) | Hero, Achievement, Contact sections |
| `VolumetricLight` | Custom (cone geometry + shader) | Achievement Hall spotlights |
| `GrabbableObject` | Custom + rapier | All draggable/throwable 3D objects |

### Reusable UI Components

| Component | Source | Used By |
|-----------|--------|---------|
| `Badge` | Custom | Cards, skill tags, trophies — pill-shaped tag |
| `TechStackTags` | Custom | Project dimensions, skill details — tag group |
| `ContactForm` | Custom + shadcn Input/Textarea | Contact section |

---

## Animation Implementation

| Animation | Library | Approach | Complexity |
|-----------|---------|----------|------------|
| **Section camera transitions** | GSAP | Animate R3F camera position/lookAt with gsap.to over 1.0-1.5s, ease-in-out-cubic | High |
| **Object focus transition** | GSAP | Sequenced timeline: camera zoom + object float + background overlay fade + panel slide | High |
| **Card entrance (drop + bounce)** | @react-three/rapier + GSAP | Physics drop from y=10, let Rapier handle bounce, GSAP for text fade-in sequencing | High |
| **Holographic shine sweep** | Custom shader | Fragment shader with animated UV offset for gradient sweep, 4s loop uniform | Medium |
| **License card flip** | GSAP | gsap.to rotation.y += Math.PI, 0.6s ease-out, trigger on click (not drag) | Low |
| **Evolution card Pokedex open** | GSAP timeline | Camera zoom → card scale 2x → hinge rotation (front slides left, back slides right) → panel slide | High |
| **Portal enter (travel through)** | GSAP + postprocessing | Camera lerp toward portal center → chromatic aberration intensify → screen wipe transition | High |
| **Master Ball opening** | GSAP timeline | Button depress flash → 0.3s pause → halves rotate apart 30° → particle burst → interface scale-in | High |
| **Achievement trophy select** | GSAP | Trophy rises + scales + rotation speeds up + beam intensifies + camera zooms | Medium |
| **Galaxy entrance** | GSAP | Core flash → arms extend → stars pop with stagger → lines stroke-draw → nebula fade | High |
| **Skill constellation line draw** | Custom (animated dash offset) | ShaderMaterial with animated dashOffset uniform for stroke animation | Medium |
| **Volumetric light beams** | Custom shader | Cone geometry with gradient opacity (1.0 top → 0.1 bottom), dust particles within | Medium |
| **Card/portal floating bob** | drei `Float` or custom | Sinusoidal Y offset with random amplitude/period per object | Low |
| **Panel slide-in/out** | framer-motion | AnimatePresence + motion.div with x: 100% ↔ 0, 0.4s | Low |
| **Hint pulse** | CSS animation | opacity 0.4→1.0, 2s loop via @keyframes | Low |
| **Loading screen fade** | framer-motion | AnimatePresence exit with opacity transition | Low |
| **Ambient object sway** | Custom (useFrame) | Apply sinusoidal rotation in useFrame loop with random phase | Low |
| **Star twinkle** | Custom (useFrame) | Random brightness variation per star in useFrame, 2-5s period | Low |
| **Galaxy auto-rotation** | Custom (useFrame) | Slow Y rotation (60s/rev), overrideable by user drag | Low |

---

## State & Logic

### Zustand Store Architecture

```typescript
interface AppState {
  // Navigation
  activeSection: number; // 0-7
  previousSection: number;
  isTransitioning: boolean;
  
  // Selection state
  selectedObject: string | null; // ID of selected card/trophy/star/portal/building
  detailPanelOpen: boolean;
  detailContent: DetailContent | null;
  
  // Camera
  cameraTarget: { position: Vector3; lookAt: Vector3 };
  cameraMode: 'free' | 'focused' | 'cinematic';
  
  // Physics interaction
  grabbedObject: string | null;
  
  // UI
  loading: boolean;
  backButtonVisible: boolean;
  currentSubsection: string | null;
}
```

### Key Logic Patterns

**Section lifecycle management:**
- Only the active section and its immediate 3D objects are rendered. Previous section unmounts with exit animation.
- Each section manages its own entrance timeline via `useEffect` triggered by activeSection change.
- `isTransitioning` flag prevents interaction during camera fly-throughs.

**Grabbing system with Rapier:**
- Raycast from camera on pointer down → find rigid body → create temporary joint constraint.
- On pointer move, update constraint target position → object follows cursor.
- On pointer up, release constraint → object retains velocity (throw).
- Distinguish click (short duration, minimal movement) from drag for flip vs grab actions.

**Camera state machine:**
- `free`: OrbitControls active, user explores.
- `focused`: GSAP drives camera to selected object, OrbitControls disabled.
- `cinematic`: Section transition fly-through, OrbitControls disabled.
- State transitions triggered by navigation HUD clicks, object selections, and back button.

**Detail panel content resolution:**
- All resume data stored in a static data module (src/data/resume.ts).
- `selectedObject` ID maps to content via lookup function — no content in component state.
- Panel receives content object, renders generically based on content type (card, trophy, skill, project, building).

---

## Other Key Decisions

### No custom WebGL renderer — stay within R3F ecosystem
The project needs custom shaders (holographic shine, volumetric lights, portal distortion), but these are implemented as custom ShaderMaterials within R3F's declarative pipeline, not a standalone WebGL renderer. This ensures consistent lifecycle management, automatic disposal, and React integration.

### Physics for grab/throw only — Rapier selective activation
Rapier physics world is created per section and cleaned up on section change. Only objects that need physics (license card, trophies, evolution cards, Master Ball) get rigid bodies. Static elements (buildings, platforms, background) use kinematic or fixed bodies for collision only.

### Audio deferred — architecture-ready but not implemented
Audio elements are defined in the design (8+ sound effects) but implementation is deferred. The component architecture should emit events (e.g., `onGrab`, `onThrow`, `onPortalEnter`) that audio hooks can subscribe to later without component changes.

### Section transitions: mount/unmount vs visibility
Each section is a top-level component that mounts when active and unmounts after exit animation completes. This prevents 8 sections' worth of 3D objects from existing simultaneously. Framer Motion's AnimatePresence handles the unmount delay. Camera lives outside sections in a persistent Canvas.

### Resume data: centralized static module
All resume content (work experiences, education, skills, projects, achievements, contact info) is stored in a single TypeScript data file. Section components import slices of this data. No API calls, no CMS — static site with dynamic 3D presentation.
